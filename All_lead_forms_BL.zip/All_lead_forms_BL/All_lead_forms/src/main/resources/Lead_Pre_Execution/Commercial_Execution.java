package Lead_Pre_Execution;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import all_Xpaths.CommercialVehicle_Loans;
import all_Xpaths.Website_Page;
import common_Package.BaseClass;
import excel_Package.Excel_Utils;

public class Commercial_Execution extends BaseClass {

	public static void SFL_Website(String INDEX, String Page_URL) {

		loadUrl(Page_URL);

		getPageUrl();

		if (Page_URL.contains("https://sitsfl.stfc.in/")) {

			System.out.println(Page_URL + "user sucessfully landed");

		} else {

			System.out.println("user hit the  wrong domain");
		}

		WebElement findElement = driver
				.findElement(By.xpath("/html/body/app-root/app-header/header/section[2]/div/div/div[2]/p/span[1]"));

		Actions ac = new Actions(driver);
		ac.moveToElement(findElement).perform();

	}

	public static void commercial_Landing_Page(String cus_name, String cus_mobile, String cus_email) throws Exception {

		Thread.sleep(3000);

		btnClick(Website_Page.getInstance().getCmv_Loans());

		Thread.sleep(3000);

		String pageUrl = getPageUrl();

		if (pageUrl.contains("https://sitsfl.stfc.in/commercial-vehicle-loan")) {

			System.out.println(pageUrl + "user landed the Commercial Vehicle Loan landing page");

		} else {

			System.out.println("user failed to land the Commercial Vehicle Loan loan page");

		}

		sendKeys(CommercialVehicle_Loans.getInstance().getCommercial_cus_name(), cus_name);

		sendKeys(CommercialVehicle_Loans.getInstance().getCommercial_cus_mobile(), cus_mobile);

		sendKeys(CommercialVehicle_Loans.getInstance().getCommercial_cus_email(), cus_email);

		btnClick(CommercialVehicle_Loans.getInstance().getCommercial_pf_apply_btn());

	}

	public static void Otp_Pop_Up(String otp_input_field) throws Exception {

		List<WebElement> findElements = driver.findElements(By.xpath("//div[@class='input_field']"));
		for (int i = 0; i < findElements.size(); ++i) {
			WebElement checkbox = findElements.get(i).findElement(By.xpath("./input"));

			sendKeys(checkbox, otp_input_field);

		}

		btnClick(CommercialVehicle_Loans.getInstance().getOtpVerifybtn());
	}

	public static void DOB(String Year,String Month,String Date) throws Exception {

		try {

			Thread.sleep(3000);

			scrollDown(CommercialVehicle_Loans.getInstance().getCommercial_loan_dob());

			btnClick(CommercialVehicle_Loans.getInstance().getCommercial_loan_dob());

			btnClick(CommercialVehicle_Loans.getInstance().getMonthAndYear());

			// List<WebElement> elements =
			// driver.findElements(By.xpath("//*[@id=\"mat-datepicker-0\"]/div"));

			WebElement ul = driver.findElement(By.xpath("//*[@id=\"mat-datepicker-0\"]/div"));// xpath of ul
			Thread.sleep(3000);
			List<WebElement> allOptions = ul.findElements(By.tagName("div"));
			for (WebElement selectLi : allOptions) {

				String text = selectLi.getText();
				
				if (text.equals(Year)) {
					selectLi.click();
					break;
				}
				
				
			}

			List<WebElement> allOptions1 = ul.findElements(By.tagName("div"));
			for (WebElement selectLi : allOptions1) {

				if (selectLi.getText().equals(Month)) {
					selectLi.click();
					break;

				}

			}
			
			List<WebElement> allOptions2 = ul.findElements(By.tagName("div"));
			for (WebElement selectLi : allOptions2) {

				if (selectLi.getText().equals(Date)) {
					selectLi.click();
					break;

				}

			}

		} catch (org.openqa.selenium.StaleElementReferenceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void loan_details(String loan_Amount, String pincode, String INDEX) throws Exception {
		
		sendKeys(CommercialVehicle_Loans.getInstance().getCommercial_cus_loanAmount(), loan_Amount);
		
		System.out.println(pincode);
		
		sendKeys(CommercialVehicle_Loans.getInstance().getCommercial_cus_pincode2(), pincode);
		
		
		btnClick(CommercialVehicle_Loans.getInstance().getCommercial_pf_apply_btn1());
		
		WebElement req_submitted = Website_Page.getInstance().getReq_submitted();
		
		req_submitted.getText();
		
		if(req_submitted.getText().contains("Request Already Registered")) {
			
			System.out.println("Lead form succeed");
			
			int parseInt = Integer.parseInt(INDEX);
			
			
			Excel_Utils.writeinexcel("Lead form submitted Sucessfully", parseInt);
			
			
			
		}else {
			
			System.out.println("Lead form issue");
			
			int parseInt = Integer.parseInt(INDEX);
			
			Excel_Utils.writeinexcel("Lead form not submitted", parseInt);
			
			
		}
		
		
	}
}
