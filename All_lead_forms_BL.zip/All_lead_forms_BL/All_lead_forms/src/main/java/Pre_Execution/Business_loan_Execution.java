package Pre_Execution;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.SkipException;
import all_Xpaths.Business_Xpaths;
import all_Xpaths.Website_Page;
import common_Package.BaseClass;

public class Business_loan_Execution extends BaseClass {

	public static void SFL_Website(String INDEX, String Page_URL) {

		loadUrl(Page_URL);

		getPageUrl();

		if (Page_URL.contains("https://sitsfl.stfc.in/")) {

			System.out.println(Page_URL + "user sucessfully landed");

		} else {

			System.out.println("user hit the  wrong domain");
		}

		WebElement findElement = driver
				.findElement(By.xpath("/html/body/app-root/app-header/header/section[2]/div/div/div[2]/p/span[1]"));

		Actions ac = new Actions(driver);
		ac.moveToElement(findElement).perform();

	}

	public static void Business_loan_Landing_Page(String cus_name, String cus_mobile, String cus_email)
			throws Exception {

		Thread.sleep(3000);

		btnClick(Website_Page.getInstance().getBusiness_Loans());

		Thread.sleep(3000);

		String pageUrl = getPageUrl();

		if (pageUrl.contains("https://sitsfl.stfc.in/business-loan")) {

			System.out.println(pageUrl + "user landed the business-loan landing page");

		} else {

			System.out.println("user failed to land the business-loan page");

		}
		Thread.sleep(5000);

		sendKeys(Business_Xpaths.getInstance().getbusiness_cus_name(), cus_name);

		sendKeys(Business_Xpaths.getInstance().getbusiness_cus_mobile(), cus_mobile);

		sendKeys(Business_Xpaths.getInstance().getbusiness_cus_email(), cus_email);

		btnClick(Business_Xpaths.getInstance().getbusiness_pf_apply_btn());

	}

	public static void Otp_Pop_Up(String otp_input_field) throws Exception {

		// ------------------------For SIT-------------------------//

		List<WebElement> findElements = driver.findElements(By.xpath("//div[@class='input_field']"));
		for (int i = 0; i < findElements.size(); ++i) {
			WebElement checkbox = findElements.get(i).findElement(By.xpath("./input"));

			sendKeys(checkbox, otp_input_field);

		}

		// ========================For UAT and LIVE----------------------//

//		Scanner sc = new Scanner(System.in);
//
//		System.out.print("Enter the OTP :");
//
//		String next = sc.next();
//
//		Thread.sleep(5000);

		btnClick(Business_Xpaths.getInstance().getbusiness_otpVerifybtn());
	}

	public static void DOB(String Year, String Month, String Date) throws Exception {

		try {

			Thread.sleep(3000);

			scrollDown(Business_Xpaths.getInstance().getbusiness_loan_dob());
			scrollDown(Business_Xpaths.getInstance().getbusiness_loan_dob());
			btnClick(Business_Xpaths.getInstance().getbusiness_loan_dob());

			btnClick(Business_Xpaths.getInstance().getbusiness_calender_elobration());

			// List<WebElement> elements =
			// driver.findElements(By.xpath("//*[@id=\"mat-datepicker-0\"]/div"));

			WebElement ul = driver.findElement(By.xpath("//*[@id=\"mat-datepicker-0\"]/div"));// xpath of ul
			Thread.sleep(3000);
			List<WebElement> allOptions = ul.findElements(By.tagName("div"));
			for (WebElement selectLi : allOptions) {

				String text = selectLi.getText();

				if (text.equals(Year)) {
					selectLi.click();
					break;
				}

			}

			List<WebElement> allOptions1 = ul.findElements(By.tagName("div"));
			for (WebElement selectLi : allOptions1) {

				if (selectLi.getText().equals(Month)) {
					selectLi.click();
					break;

				}

			}

			List<WebElement> allOptions2 = ul.findElements(By.tagName("div"));
			for (WebElement selectLi : allOptions2) {

				if (selectLi.getText().equals(Date)) {
					selectLi.click();
					break;

				}

			}

		} catch (org.openqa.selenium.StaleElementReferenceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void loan_details(String loan_Amount, String pincode, String Bussiness_nature, String INDEX)
			throws Exception {

//		if (displayed(Business_Xpaths.getInstance().getbusiness_FileUpload_Stage())) {
//			throw new SkipException("Exiting Customer");
//		}

		// System.out.println(loan_Amount);

		try {
			Business_Xpaths.getInstance().getbusiness_cus_loanAmount().clear();

			sendKeys(Business_Xpaths.getInstance().getbusiness_cus_loanAmount(), loan_Amount);

			sendKeys(Business_Xpaths.getInstance().getbusiness_cus_pincode2(), pincode);

			Business_Xpaths.getInstance().getbusiness_nature().click();

			if (Bussiness_nature.equals("SME")) {
				Business_Xpaths.getInstance().getsmeLoan().click();
			} else {
				Business_Xpaths.getInstance().gettransportLoan().click();
			}

			btnClick(Business_Xpaths.getInstance().getbusiness_pf_apply_btn1());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void personal_details(String Pan_no, String Gender, String Marital_Status, String Residence_Type,
			String Years_living) throws InterruptedException {

		try {
			sendKeys(Business_Xpaths.getInstance().getbusiness_cus_pan(), Pan_no);

			Business_Xpaths.getInstance().getbusiness_cus_gender().click();

			// Thread.sleep(3000);
			if (Gender.equals("Male")) {
				Business_Xpaths.getInstance().getbusiness_cus_gender_male().click();
			} else if (Gender.equals("Female")) {
				Business_Xpaths.getInstance().getbusiness_cus_gender_female().click();
			} else {
				Business_Xpaths.getInstance().getbusiness_cus_gender_others().click();
			}

			// Thread.sleep(3000);
			Business_Xpaths.getInstance().getbusiness_cus_marital_status().click();
			if (Marital_Status.equals("Single")) {
				Business_Xpaths.getInstance().getbusiness_cus_marital_status_single().click();
			} else if (Marital_Status.equals("Married")) {
				Business_Xpaths.getInstance().getbusiness_cus_marital_status_married().click();
			}
			// Thread.sleep(3000);
			Click(Business_Xpaths.getInstance().getbusiness_agree_checkbox());
			// Thread.sleep(3000);
			btnClick(Business_Xpaths.getInstance().getbusiness_stepbtn_1());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void Business_loan_Residental_details(String Residence_Type, String Years_living) {

		try {
			// Thread.sleep(3000);
			Click(Business_Xpaths.getInstance().getbusiness_cus_res());
			// Thread.sleep(3000);
			// System.out.println(Residence_Type);
			if (Residence_Type.equals("Owned by self/spouse")) {
				Click(Business_Xpaths.getInstance().getbusiness_Res_type_Rented_with_Family());
			} else if (Residence_Type.equals("Owned By Parent/Sibling")) {
				Click(Business_Xpaths.getInstance().getbusiness_Res_type_Owned_By_Parent_Sibling());
			} else if (Residence_Type.equals("Rented with Family")) {
				Click(Business_Xpaths.getInstance().getbusiness_Res_type_Rented_with_Family());
			} else if (Residence_Type.equals("Rented with Friends")) {
				Click(Business_Xpaths.getInstance().getbusiness_Res_type_Rented_with_Friends());
			} else if (Residence_Type.equals("Rented Staying Alone")) {
				Click(Business_Xpaths.getInstance().getbusiness_Res_type_Rented_Staying_Alone());
			} else if (Residence_Type.equals("Paying Guest")) {
				Click(Business_Xpaths.getInstance().getbusiness_Res_type_Paying_Guest());
			} else if (Residence_Type.equals("Hostel")) {
				Click(Business_Xpaths.getInstance().getbusiness_Res_type_Hostel());
			} else if (Residence_Type.equals("Company Provided")) {
				Click(Business_Xpaths.getInstance().getbusiness_Res_Company_Provided());
			}

			Click(Business_Xpaths.getInstance().getbusiness_cus_res_live_years());
			// Thread.sleep(3000);
			// System.out.println(Years_living);
			if (Years_living.equals("<1")) {
				Click(Business_Xpaths.getInstance().getbusiness_LiveyearLessthan_one());
			} else if (Years_living.equals("1")) {
				Click(Business_Xpaths.getInstance().getbusiness_Liveyear_one());

			} else if (Years_living.equals("2")) {
				Click(Business_Xpaths.getInstance().getbusiness_Liveyear_two());

			} else if (Years_living.equals("3")) {
				Click(Business_Xpaths.getInstance().getbusiness_Liveyear_three());

			} else if (Years_living.equals("4")) {
				Click(Business_Xpaths.getInstance().getbusiness_Liveyear_four());

			} else if (Years_living.equals("5")) {
				Click(Business_Xpaths.getInstance().getbusiness_Liveyear_five());

			} else if (Years_living.equals(">5")) {
				Click(Business_Xpaths.getInstance().getbusiness_Liveyear_Greaterfive());

			}
			// Thread.sleep(3000);
			btnClick(Business_Xpaths.getInstance().getbusiness_stepbtn_2());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void business_informations(String Business_name, String Business_type, String Business_premises,
			String Type_of_collateral, String Year_of_business, String Business_Pincode, String Annual_Turnover,
			String Business_Proof, String Gst) {

		try {
			sendKeys(Business_Xpaths.getInstance().getbusiness_name(), Business_name);

			Click(Business_Xpaths.getInstance().getbusiness_type());
			// Thread.sleep(3000);

			if (Business_type.equals("Proprietor")) {
				Click(Business_Xpaths.getInstance().getbusiness_type_Partnership());
			} else if (Business_type.equals("Partnership")) {
				Click(Business_Xpaths.getInstance().getbusiness_type_Partnership());

			} else if (Business_type.equals("Private Limited")) {
				Click(Business_Xpaths.getInstance().getbusiness_type_Private_Limited());

			} else if (Business_type.equals("Limited Company")) {
				Click(Business_Xpaths.getInstance().getbusiness_type_Limited_Company());

			}

			Click(Business_Xpaths.getInstance().getbusiness_premises());
			// Thread.sleep(3000);
			if (Business_premises.equals("RCC with Shutter in Residential Area")) {
				Click(Business_Xpaths.getInstance().getbusiness_premises_rcc_residential());
			} else if (Business_premises.equals("RCC with Shutter in Market")) {
				Click(Business_Xpaths.getInstance().getbusiness_premises_rcc_market());

			} else if (Business_premises.equals("Shop in Shopping Complex/ Mall")) {
				Click(Business_Xpaths.getInstance().getbusiness_premises_shop_complex_mall());

			} else if (Business_premises.equals("Industrial Office")) {
				Click(Business_Xpaths.getInstance().getbusiness_premises_industrial_office());

			} else if (Business_premises.equals("Administrative Office")) {
				Click(Business_Xpaths.getInstance().getbusiness_premises_administrative_Office());

			}

			Click(Business_Xpaths.getInstance().getbusiness_collateral());
			// Thread.sleep(3000);
			if (Type_of_collateral.equals("Agricultural Collateral")) {
				Click(Business_Xpaths.getInstance().getbusiness_collatType_Agricultural_Collateral());
			} else if (Type_of_collateral.equals("Commercial Collateral")) {
				Click(Business_Xpaths.getInstance().getbusiness_collatType_Commercial_Collateral());
			} else if (Type_of_collateral.equals("Residential Collateral")) {
				Click(Business_Xpaths.getInstance().getbusiness_collatType_Residential_Collateral());
			} else if (Type_of_collateral.equals("No Collateral, No Guarantor")) {
				Click(Business_Xpaths.getInstance().getbusiness_collatType_NoCollateral_NoGuarantor());
			} else if (Type_of_collateral.equals("Only Guarantor")) {
				Click(Business_Xpaths.getInstance().getbusiness_collatType_Only_Guarantor());
			}

			Click(Business_Xpaths.getInstance().getbusiness_in_Years());

			if (Year_of_business.equals("<1")) {
				Click(Business_Xpaths.getInstance().getbusiness_BusinessinLessthan_oneyear());
			} else if (Year_of_business.equals("1")) {
				Click(Business_Xpaths.getInstance().getbusiness_Businessin_oneyear());

			} else if (Year_of_business.equals("2")) {
				Click(Business_Xpaths.getInstance().getbusiness_Businessin_twoyear());

			} else if (Year_of_business.equals("3")) {
				Click(Business_Xpaths.getInstance().getbusiness_Businessin_threeyear());

			} else if (Year_of_business.equals("4")) {
				Click(Business_Xpaths.getInstance().getbusiness_Businessin_fouryear());

			} else if (Year_of_business.equals("5")) {
				Click(Business_Xpaths.getInstance().getbusiness_Businessin_fiveyear());

			} else if (Year_of_business.equals(">5")) {
				Click(Business_Xpaths.getInstance().getbusiness_Businessin_Greaterfiveyear());

			}

			sendKeys(Business_Xpaths.getInstance().getbusiness_pincode(), Business_Pincode);

			sendKeys(Business_Xpaths.getInstance().getbusiness_annual_turnover(), Annual_Turnover);

			Click(Business_Xpaths.getInstance().getbusiness_proof_no());
			// Thread.sleep(3000);
			Click(Business_Xpaths.getInstance().getbusiness_gst_no());
			// Thread.sleep(3000);
			Click(Business_Xpaths.getInstance().getbusiness_final_submit());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void businessdocument_upload_process(String ID_proofdoc, String Addres_proofdoc,
			String BusinessIncomeDoc) {

		// Thread.sleep(3000);
		// uploadElement.sendKeys("C:\\newhtml.html");
		// sendKeys(Business_Xpaths.getInstance().getbusiness_id_proof(), ID_proofdoc);

		// Thread.sleep(3000);
		try {
			driver.findElement(By.xpath("//*[@id=\"fd-upload\"]/form/div/div[1]/div/div[1]/div/div[1]/input"))
					.sendKeys("C:/Users/e078/Pictures/flowerpng.png");

			// Thread.sleep(3000);
			driver.findElement(By.xpath("//*[@id=\"fd-upload\"]/form/div/div[1]/div/div[2]/div/div[1]/input"))
					.sendKeys("C:/Users/e078/Pictures/flowerpng.png");

			// Thread.sleep(3000);
			driver.findElement(By.xpath("//*[@id=\"fd-upload\"]/form/div/div[1]/div/div[3]/div/div[1]/input"))
					.sendKeys("C:/Users/e078/Pictures/flowerpng.png");

			Click(Business_Xpaths.getInstance().getbusiness_Stage3_submit());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

//		Click(Business_Xpaths.getInstance().getbusiness_id_proof());

	}
}
