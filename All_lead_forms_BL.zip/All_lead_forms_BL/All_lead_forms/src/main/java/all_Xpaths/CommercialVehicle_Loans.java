package all_Xpaths;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CommercialVehicle_Loans {

	private static CommercialVehicle_Loans xpathsPageInstance;

	private CommercialVehicle_Loans() {

	}

	public static CommercialVehicle_Loans getInstance() {
		if (xpathsPageInstance == null) {
			xpathsPageInstance = new CommercialVehicle_Loans();
		}
		return xpathsPageInstance;
	}

	@FindBy(id = "cus_name")
	private WebElement commercial_cus_name;

	public WebElement getCommercial_cus_name() {
		return commercial_cus_name;
	}

	@FindBy(id = "cus_mobile")
	private WebElement Commercial_cus_mobile;

	public WebElement getCommercial_cus_mobile() {
		return Commercial_cus_mobile;
	}

	@FindBy(id = "cus_email")
	private WebElement commercial_cus_email;

	public WebElement getCommercial_cus_email() {
		return commercial_cus_email;
	}

	@FindBy(id = "pf-apply-btn")
	private WebElement commercial_pf_apply_btn;

	public WebElement getCommercial_pf_apply_btn() {
		return commercial_pf_apply_btn;
	}

	@FindBy(xpath = "//div[@class='input_field']")
	private WebElement commercial_otp_field;

	public WebElement getCommercial_otp_field() {
		return commercial_otp_field;
	}

	@FindBy(id = "changeMobNo")
	private WebElement commercial_changeMobNo;

	public WebElement getCommercial_changeMobNo() {
		return commercial_changeMobNo;
	}

	@FindBy(id = "otpVerifybtn")
	private WebElement otpVerifybtn;

	public WebElement getOtpVerifybtn() {
		return otpVerifybtn;
	}

	@FindBy(id = "loan-dob")
	private WebElement commercial_loan_dob;

	public WebElement getCommercial_loan_dob() {
		return commercial_loan_dob;
	}
	
	@FindBy(xpath="//button[@aria-label='Choose month and year']")
	private WebElement monthAndYear;

	public WebElement getMonthAndYear() {
		return monthAndYear;
	}
	
	@FindBy(xpath="//div[@class='mat-calendar-content']")
	private WebElement yy_mm_dd;

	public WebElement getYy_mm_dd() {
		return yy_mm_dd;
	}

	@FindBy(id = "cus_loanAmount")
	private WebElement commercial_cus_loanAmount;

	public WebElement getCommercial_cus_loanAmount() {
		return commercial_cus_loanAmount;
	}

	@FindBy(id = "cus_pincode2")
	private WebElement commercial_cus_pincode2;

	public WebElement getCommercial_cus_pincode2() {
		return commercial_cus_pincode2;
	}

	@FindBy(id = "pf-apply-btn1")
	private WebElement commercial_pf_apply_btn1;

	public WebElement getCommercial_pf_apply_btn1() {
		return commercial_pf_apply_btn1;
	}

}
