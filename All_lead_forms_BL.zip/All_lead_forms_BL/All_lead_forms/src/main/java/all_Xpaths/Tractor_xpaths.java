package all_Xpaths;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class Tractor_xpaths {
	
	private static Tractor_xpaths xpathsPageInstance;

	private Tractor_xpaths() {

	}

	public static Tractor_xpaths getInstance() {
		if (xpathsPageInstance == null) {
			xpathsPageInstance = new Tractor_xpaths();
		}
		return xpathsPageInstance;
	}
	
	
	public WebElement gettractor_cus_name() {
		return tractor_cus_name;
	}

	public WebElement gettractor_cus_mobile() {
		return tractor_cus_mobile;
	}

	public WebElement gettractor_cus_email() {
		return tractor_cus_email;
	}

	public WebElement gettractor_pf_apply_btn() {
		return tractor_pf_apply_btn;
	}

	public WebElement gettractor_otp_field() {
		return tractor_otp_field;
	}

	public WebElement gettractor_otpVerifybtn() {
		return tractor_otpVerifybtn;
	}


	@CacheLookup
	@FindBy(id="cus_name")
	private WebElement tractor_cus_name;
	
	@FindBy(id="cus_mobile")
	private WebElement tractor_cus_mobile;
	
	@FindBy(id="cus_email")
	private WebElement tractor_cus_email;
	
	@FindBy(id="pf-apply-btn")
	private WebElement tractor_pf_apply_btn;

	@FindBy(xpath="//div[@class='input_field']")
	private WebElement tractor_otp_field;
	
	@FindBy(id="otpVerifybtn")
	private WebElement tractor_otpVerifybtn;
	
	public WebElement gettractor_loan_dob() {
		return tractor_loan_dob;
	}

	public WebElement gettractor_calender_elobration() {
		return tractor_calender_elobration;
	}

	public WebElement gettractor_cus_loanAmount() {
		return tractor_cus_loanAmount;
	}

	public WebElement gettractor_cus_pincode2() {
		return tractor_cus_pincode2;
	}

	public WebElement gettractor_pf_apply_btn1() {
		return tractor_pf_apply_btn1;
	}


	@FindBy(id="loan-dob")
	private WebElement tractor_loan_dob;
	
	@FindBy(xpath="//*[@id=\"mat-datepicker-0\"]/mat-calendar-header/div/div/button[1]")
	private WebElement tractor_calender_elobration;
	
	@FindBy(id="cus_loanAmount")
	private WebElement tractor_cus_loanAmount;
	
	@FindBy(id="cus_pincode2")
	private WebElement tractor_cus_pincode2;
	
	@FindBy(id="pf-apply-btn1")
	private WebElement tractor_pf_apply_btn1;

}
