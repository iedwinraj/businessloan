package all_Xpaths;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class Challan_Xpaths {
	
	private static Challan_Xpaths xpathsPageInstance;

	private Challan_Xpaths() {

	}

	public static Challan_Xpaths getInstance() {
		if (xpathsPageInstance == null) {
			xpathsPageInstance = new Challan_Xpaths();
		}
		return xpathsPageInstance;
	}
	
	
	public WebElement getchallan_cus_name() {
		return challan_cus_name;
	}

	public WebElement getchallan_cus_mobile() {
		return challan_cus_mobile;
	}

	public WebElement getchallan_cus_email() {
		return challan_cus_email;
	}

	public WebElement getchallan_pf_apply_btn() {
		return challan_pf_apply_btn;
	}

	public WebElement getchallan_otp_field() {
		return challan_otp_field;
	}

	public WebElement getchallan_otpVerifybtn() {
		return challan_otpVerifybtn;
	}

	public WebElement getchallan_loan_dob() {
		return challan_loan_dob;
	}

	public WebElement getchallan_calender_elobration() {
		return challan_calender_elobration;
	}

	public WebElement getchallan_cus_loanAmount() {
		return challan_cus_loanAmount;
	}

	public WebElement getchallan_cus_pincode2() {
		return challan_cus_pincode2;
	}

	public WebElement getchallan_pf_apply_btn1() {
		return challan_pf_apply_btn1;
	}


	@CacheLookup
	@FindBy(id="cus_name")
	private WebElement challan_cus_name;
	
	@FindBy(id="cus_mobile")
	private WebElement challan_cus_mobile;
	
	@FindBy(id="cus_email")
	private WebElement challan_cus_email;
	
	@FindBy(id="pf-apply-btn")
	private WebElement challan_pf_apply_btn;

	@FindBy(xpath="//div[@class='input_field']")
	private WebElement challan_otp_field;
	
	@FindBy(id="otpVerifybtn")
	private WebElement challan_otpVerifybtn;
	
	@FindBy(id="loan-dob")
	private WebElement challan_loan_dob;
	
	@FindBy(xpath="//*[@id=\"mat-datepicker-0\"]/mat-calendar-header/div/div/button[1]")
	private WebElement challan_calender_elobration;
	
	@FindBy(id="cus_loanAmount")
	private WebElement challan_cus_loanAmount;
	
	@FindBy(id="cus_pincode2")
	private WebElement challan_cus_pincode2;
	
	@FindBy(id="pf-apply-btn1")
	private WebElement challan_pf_apply_btn1;

}
