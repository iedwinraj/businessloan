package all_Xpaths;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class Tax_Xpaths {

	private static Tax_Xpaths xpathsPageInstance;

	private Tax_Xpaths() {

	}

	public static Tax_Xpaths getInstance() {
		if (xpathsPageInstance == null) {
			xpathsPageInstance = new Tax_Xpaths();
		}
		return xpathsPageInstance;
	}
	
	
	public WebElement gettax_cus_name() {
		return tax_cus_name;
	}

	public WebElement gettax_cus_mobile() {
		return tax_cus_mobile;
	}

	public WebElement gettax_cus_email() {
		return tax_cus_email;
	}

	public WebElement gettax_pf_apply_btn() {
		return tax_pf_apply_btn;
	}

	public WebElement gettax_otp_field() {
		return tax_otp_field;
	}

	public WebElement gettax_otpVerifybtn() {
		return tax_otpVerifybtn;
	}

	public WebElement gettax_loan_dob() {
		return tax_loan_dob;
	}

	public WebElement gettax_calender_elobration() {
		return tax_calender_elobration;
	}

	public WebElement gettax_cus_loanAmount() {
		return tax_cus_loanAmount;
	}

	public WebElement gettax_cus_pincode2() {
		return tax_cus_pincode2;
	}

	public WebElement gettax_pf_apply_btn1() {
		return tax_pf_apply_btn1;
	}


	@CacheLookup
	@FindBy(id="cus_name")
	private WebElement tax_cus_name;
	
	@FindBy(id="cus_mobile")
	private WebElement tax_cus_mobile;
	
	@FindBy(id="cus_email")
	private WebElement tax_cus_email;
	
	@FindBy(id="pf-apply-btn")
	private WebElement tax_pf_apply_btn;

	@FindBy(xpath="//div[@class='input_field']")
	private WebElement tax_otp_field;
	
	@FindBy(id="otpVerifybtn")
	private WebElement tax_otpVerifybtn;
	
	@FindBy(id="loan-dob")
	private WebElement tax_loan_dob;
	
	@FindBy(xpath="//*[@id=\"mat-datepicker-0\"]/mat-calendar-header/div/div/button[1]")
	private WebElement tax_calender_elobration;
	
	@FindBy(id="cus_loanAmount")
	private WebElement tax_cus_loanAmount;
	
	@FindBy(id="cus_pincode2")
	private WebElement tax_cus_pincode2;
	
	@FindBy(id="pf-apply-btn1")
	private WebElement tax_pf_apply_btn1;
	
}
