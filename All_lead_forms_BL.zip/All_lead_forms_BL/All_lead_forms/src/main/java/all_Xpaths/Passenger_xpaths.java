package all_Xpaths;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class Passenger_xpaths {
	private static Passenger_xpaths xpathsPageInstance;

	private Passenger_xpaths() {

	}

	public static Passenger_xpaths getInstance() {
		if (xpathsPageInstance == null) {
			xpathsPageInstance = new Passenger_xpaths();
		}
		return xpathsPageInstance;
	}
	
	
	@CacheLookup
	@FindBy(id="cus_name")
	private WebElement passenger_cus_name;
	
	@FindBy(id="cus_mobile")
	private WebElement passenger_cus_mobile;
	
	@FindBy(id="cus_email")
	private WebElement passenger_cus_email;
	
	@FindBy(id="pf-apply-btn")
	private WebElement passenger_pf_apply_btn;

	@FindBy(xpath="//div[@class='input_field']")
	private WebElement passenger_otp_field;
	
	@FindBy(id="otpVerifybtn")
	private WebElement passenger_otpVerifybtn;
	
	public WebElement getpassenger_cus_name() {
		return passenger_cus_name;
	}

	public WebElement getpassenger_cus_mobile() {
		return passenger_cus_mobile;
	}

	public WebElement getpassenger_cus_email() {
		return passenger_cus_email;
	}

	public WebElement getpassenger_pf_apply_btn() {
		return passenger_pf_apply_btn;
	}

	public WebElement getpassenger_otp_field() {
		return passenger_otp_field;
	}

	public WebElement getpassenger_otpVerifybtn() {
		return passenger_otpVerifybtn;
	}

	public WebElement getpassenger_loan_dob() {
		return passenger_loan_dob;
	}

	public WebElement getpassenger_calender_elobration() {
		return passenger_calender_elobration;
	}

	public WebElement getpassenger_cus_loanAmount() {
		return passenger_cus_loanAmount;
	}

	public WebElement getpassenger_cus_pincode2() {
		return passenger_cus_pincode2;
	}

	public WebElement getpassenger_pf_apply_btn1() {
		return passenger_pf_apply_btn1;
	}


	@FindBy(id="loan-dob")
	private WebElement passenger_loan_dob;
	
	@FindBy(xpath="//*[@id=\"mat-datepicker-0\"]/mat-calendar-header/div/div/button[1]")
	private WebElement passenger_calender_elobration;
	
	@FindBy(id="cus_loanAmount")
	private WebElement passenger_cus_loanAmount;
	
	@FindBy(id="cus_pincode2")
	private WebElement passenger_cus_pincode2;
	
	@FindBy(id="pf-apply-btn1")
	private WebElement passenger_pf_apply_btn1;

	

}
