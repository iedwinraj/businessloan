package all_Xpaths;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class Vehicle_Ins_xpaths {

	private static Vehicle_Ins_xpaths xpathsPageInstance;

	private Vehicle_Ins_xpaths() {

	}

	public static Vehicle_Ins_xpaths getInstance() {
		if (xpathsPageInstance == null) {
			xpathsPageInstance = new Vehicle_Ins_xpaths();
		}
		return xpathsPageInstance;
	}
	
	
	@CacheLookup
	@FindBy(id="cus_name")
	private WebElement vehicle_cus_name;
	
	@FindBy(id="cus_mobile")
	private WebElement vehicle_cus_mobile;
	
	@FindBy(id="cus_email")
	private WebElement vehicle_cus_email;
	
	@FindBy(id="pf-apply-btn")
	private WebElement vehicle_pf_apply_btn;

	public WebElement getVehicle_cus_name() {
		return vehicle_cus_name;
	}

	public WebElement getVehicle_cus_mobile() {
		return vehicle_cus_mobile;
	}

	public WebElement getVehicle_cus_email() {
		return vehicle_cus_email;
	}

	public WebElement getVehicle_pf_apply_btn() {
		return vehicle_pf_apply_btn;
	}

	public WebElement getVehicle_otp_field() {
		return vehicle_otp_field;
	}

	public WebElement getVehicle_otpVerifybtn() {
		return vehicle_otpVerifybtn;
	}

	public WebElement getVehicle_loan_dob() {
		return vehicle_loan_dob;
	}

	public WebElement getVehicle_calender_elobration() {
		return vehicle_calender_elobration;
	}

	public WebElement getVehicle_cus_loanAmount() {
		return vehicle_cus_loanAmount;
	}

	public WebElement getVehicle_cus_pincode2() {
		return vehicle_cus_pincode2;
	}

	public WebElement getVehicle_pf_apply_btn1() {
		return vehicle_pf_apply_btn1;
	}


	@FindBy(xpath="//div[@class='input_field']")
	private WebElement vehicle_otp_field;
	
	@FindBy(id="otpVerifybtn")
	private WebElement vehicle_otpVerifybtn;
	
	@FindBy(id="loan-dob")
	private WebElement vehicle_loan_dob;
	
	@FindBy(xpath="//*[@id=\"mat-datepicker-0\"]/mat-calendar-header/div/div/button[1]")
	private WebElement vehicle_calender_elobration;
	
	@FindBy(id="cus_loanAmount")
	private WebElement vehicle_cus_loanAmount;
	
	@FindBy(id="cus_pincode2")
	private WebElement vehicle_cus_pincode2;
	
	@FindBy(id="pf-apply-btn1")
	private WebElement vehicle_pf_apply_btn1;
	
}
