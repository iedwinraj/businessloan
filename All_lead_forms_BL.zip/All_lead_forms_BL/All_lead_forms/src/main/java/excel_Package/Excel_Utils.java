package excel_Package;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel_Utils {

	static Read_Excel reader;

	public static ArrayList<Object[]> getDataFromexcel() {
		ArrayList<Object[]> myData = new ArrayList<Object[]>();
		try {
			String s = "D:\\S2605\\All_lead_forms\\Excel\\BusinessLoan.xlsx";
			//System.out.println(s);
			reader = new Read_Excel(s);

		} catch (Exception e) {
			e.printStackTrace();
		}

		for (int rowNum = 2; rowNum <= reader.getRowCount("Sheet1"); rowNum++) {

			// INDEX
			String INDEX = reader.getCellData("Sheet1", "INDEX", rowNum);
			// Page_URL
			String Page_URL = reader.getCellData("Sheet1", "Page_URL", rowNum);
			// Leads
			String Leads = reader.getCellData("Sheet1", "Leads", rowNum);
			// cus_name
			String cus_name = reader.getCellData("Sheet1", "cus_name", rowNum);
			// cus_mobile
			String cus_mobile = reader.getCellData("Sheet1", "cus_mobile", rowNum);
			// cus_email
			String cus_email = reader.getCellData("Sheet1", "cus_email", rowNum);
			// otp_input_field
			String otp_input_field = reader.getCellData("Sheet1", "otp_input_field", rowNum);
			// Year
			String Year = reader.getCellData("Sheet1", "Year", rowNum);
			// Month
			String Month = reader.getCellData("Sheet1", "Month", rowNum);
			// Date
			String Date = reader.getCellData("Sheet1", "Date", rowNum);
			// loan_Amount
			String loan_Amount = reader.getCellData("Sheet1", "loan_Amount", rowNum);
			// pincode
			String pincode = reader.getCellData("Sheet1", "pincode", rowNum);
			// Bussiness_nature
			String Bussiness_nature = reader.getCellData("Sheet1", "Bussiness_nature", rowNum);
			// Pan_no
			String Pan_no = reader.getCellData("Sheet1", "Pan_no", rowNum);
			// Gender
			String Gender = reader.getCellData("Sheet1", "Gender", rowNum);
			// Marital_Status
			String Marital_Status = reader.getCellData("Sheet1", "Marital_Status", rowNum);
			// Residence_Type
			String Residence_Type = reader.getCellData("Sheet1", "Residence_Type", rowNum);
			// Years_living
			String Years_living = reader.getCellData("Sheet1", "Years_living", rowNum);
			// Business_name
			String Business_name = reader.getCellData("Sheet1", "Business_name", rowNum);
			// Business_type
			String Business_type = reader.getCellData("Sheet1", "Business_type", rowNum);
			// Business_premises
			String Business_premises = reader.getCellData("Sheet1", "Business_premises", rowNum);
			// Type_of_collateral
			String Type_of_collateral = reader.getCellData("Sheet1", "Type_of_collateral", rowNum);
			// Year_of_business
			String Year_of_business = reader.getCellData("Sheet1", "Year_of_business", rowNum);
			// Business_Pincode
			String Business_Pincode = reader.getCellData("Sheet1", "Business_Pincode", rowNum);
			// Annual_Turnover
			String Annual_Turnover = reader.getCellData("Sheet1", "Annual_Turnover", rowNum);
			// Business_Proof
			String Business_Proof = reader.getCellData("Sheet1", "Business_Proof", rowNum);
			// Gst
			String Gst = reader.getCellData("Sheet1", "Gst", rowNum);
			// ID_proofdoc
			String ID_proofdoc = reader.getCellData("Sheet1", "ID_proofdoc", rowNum);
			// Address-proof
			String Addres_proofdoc = reader.getCellData("Sheet1", "Addres_proofdoc", rowNum);
			// BusinessIncomeprrof
			String BusinessIncomeDoc = reader.getCellData("Sheet1", "BusinessIncomeDoc", rowNum);

			Object ob[] = { INDEX, Page_URL, Leads, cus_name, cus_mobile, cus_email, otp_input_field, Year, Month, Date,
					loan_Amount, pincode, Bussiness_nature, Pan_no, Gender, Marital_Status, Residence_Type,
					Years_living, Business_name, Business_type, Business_premises, Type_of_collateral, Year_of_business,
					Business_Pincode, Annual_Turnover, Business_Proof, Gst, ID_proofdoc, Addres_proofdoc,
					BusinessIncomeDoc };
			myData.add(ob);
			//System.out.println(myData);
		}
		return myData;

	}

	public static void writeinexcel(String value, int INDEX) throws Exception {
		File fis = new File("D:\\S2605\\All_lead_forms\\Excel\\BusinessLoan.xlsx");
		FileInputStream excelloc = new FileInputStream(fis);
		@SuppressWarnings("resource")
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(0);
		XSSFRow row = s.getRow(INDEX);
		XSSFCell c = row.createCell(13);
		c.setCellValue(value);
		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();
	}

}
