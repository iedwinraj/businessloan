package lead_Runner_Pac;

import java.util.Scanner;

public class Bcl_Calculator {
	
	public static void main(String[] args) {

		System.out.println("Enter user's " + " Annual Turnover " + ": ");
		Scanner s = new Scanner(System.in);
		int Annual_Turnover = s.nextInt();
		System.out.println("Your " + " Annual Turnover " + " is " + Annual_Turnover);

		System.out.println("Enter user's " + " Profit Margin " + ": ");
		int Profit_Margin_Declared = s.nextInt();
		double Profit_margin_Declared = Profit_Margin_Declared;
		System.out.println("User's " + " Profit Margin " + " is " + Profit_margin_Declared);

		int a = 4000000;
		int b = 10000000;
		int c = 30000000;

		
		int fourtylacs_to_onehundredLacs = 50;
		int onehundredLacs_to_threehundredLacs = 55;
		int above_threehundredLacs = 60;
		
		
		double divide = 100;
		double max_Manufacturing_Percent = 15;
		double max_Service_Percent = 17;
		double max_Trading_Percent = 7;

		// double[] array = {0.15,0.17,0.07};

		
//***********************************************Annual_Turnover is 40<=100 lacs*******************************************************************		

		
		// If Annual_Turnover is 40<=100 lacs
		if (Annual_Turnover >= a && Annual_Turnover <= b) {

			//Foir is 50%			
			System.out.println("Foir is "+fourtylacs_to_onehundredLacs + "%");

			System.out.println("Please enter Nature Of Business : ");
			
			//Nature of business to be entered				
			String NOB = s.next();
			
			System.out.println("User choosen NOB is "+NOB);
			
			switch (NOB.toLowerCase()) {
			
			case "manufacturing":
				
				//If profit margin is greater than or equal to 15 for manufacturing, it'll consider as 15%			
				if (Profit_margin_Declared / divide >= max_Manufacturing_Percent / divide) {

					// Net monthly income formula (A*Min(C,D))/12					
					double net_Income_Monthly = ((Annual_Turnover * Math.min(max_Manufacturing_Percent / divide, Profit_margin_Declared / divide)) / 12);

					//Profit margin declared
					System.out.println("Profit margin declared is "+Math.min(max_Manufacturing_Percent / divide, Profit_margin_Declared / divide));				
					
					//Calculated Net Income Monthly				
					System.out.println("Calculated Net Income Monthly is "+net_Income_Monthly);				
									
					// Net disposable income formula E(fourtylacs_to_onehundredLacs) * E1(net_Income_Monthly)				
					int Net_Disposable_Income = (int) (net_Income_Monthly * fourtylacs_to_onehundredLacs / divide);

					// Consolidated Net disposable income				
					System.out.println("Your Net disposable income is  "+Net_Disposable_Income);	
					
					System.out.println("Enter the Current EMI : ");				
					
					// Current EMI have to be entered					
					int Current_EMI = s.nextInt();
					
					// Calculated Permissible EMI 
					int Permissible_EMI = Net_Disposable_Income - Current_EMI;
					
					System.out.println("Your permissible EMI is : "+Permissible_EMI);
	
				}

				//If profit margin is lower than 15 for manufacturing, it'll consider as entered lower value 			
				else if (Profit_margin_Declared/divide < max_Manufacturing_Percent/divide) {

					// Net monthly income formula (A*Min(C,D))/12
					double net_Income_Monthly = ((Annual_Turnover * Math.min(max_Manufacturing_Percent/divide, Profit_margin_Declared/divide)) / 12);

					//Calculated Net Income Monthly				
					System.out.println("Calculated Net Income Monthly"+net_Income_Monthly);				
									
					// Net disposable income formula E(fourtylacs_to_onehundredLacs) * E1(net_Income_Monthly)
					int Net_Disposable_Income = (int) (net_Income_Monthly * fourtylacs_to_onehundredLacs / divide);

					// Consolidated Net disposable income				
					System.out.println("Your Net disposable income is  "+Net_Disposable_Income);	
					
					System.out.println("Enter the Current EMI : ");				
					
					// Current EMI have to be entered					
					int Current_EMI = s.nextInt();
					
					// Calculated Permissible EMI 
					int Permissible_EMI = Net_Disposable_Income - Current_EMI;
					
					System.out.println("Your permissible EMI is : "+Permissible_EMI);
				}
				
				break;
			
				
				
			case "service":
				
				//If profit margin is greater than or equal to 15 for Service, it'll consider as 15%			
				if (Profit_margin_Declared / divide >= max_Service_Percent / divide) {

					// Net monthly income formula (A*Min(C,D))/12					
					double net_Income_Monthly = ((Annual_Turnover * Math.min(max_Service_Percent / divide, Profit_margin_Declared / divide)) / 12);

					//Profit margin declared
					System.out.println("Profit margin declared is "+Math.min(max_Service_Percent / divide, Profit_margin_Declared / divide));				
					
					//Calculated Net Income Monthly				
					System.out.println("Calculated Net Income Monthly is "+net_Income_Monthly);				
									
					// Net disposable income formula E(fourtylacs_to_onehundredLacs) * E1(net_Income_Monthly)				
					int Net_Disposable_Income = (int) (net_Income_Monthly * fourtylacs_to_onehundredLacs / divide);

					// Consolidated Net disposable income				
					System.out.println("Your Net disposable income is  "+Net_Disposable_Income);	
					
					System.out.println("Enter the Current EMI : ");				
					
					// Current EMI have to be entered					
					int Current_EMI = s.nextInt();
					
					// Calculated Permissible EMI 
					int Permissible_EMI = Net_Disposable_Income - Current_EMI;
					
					System.out.println("Your permissible EMI is : "+Permissible_EMI);	
					
				}

				//If profit margin is lower than 15 for service, it'll consider as entered lower value 			
				else if (Profit_margin_Declared/divide < max_Service_Percent/divide) {

					// Net monthly income formula (A*Min(C,D))/12
					double net_Income_Monthly = ((Annual_Turnover * Math.min(max_Service_Percent/divide, Profit_margin_Declared/divide)) / 12);

					//Calculated Net Income Monthly				
					System.out.println("Calculated Net Income Monthly"+net_Income_Monthly);				
									
					// Net disposable income formula E(fourtylacs_to_onehundredLacs) * E1(net_Income_Monthly)
					int Net_Disposable_Income = (int) (net_Income_Monthly * fourtylacs_to_onehundredLacs / divide);

					// Consolidated Net disposable income				
					System.out.println("Your Net disposable income is  "+Net_Disposable_Income);	
					
					System.out.println("Enter the Current EMI : ");				
					
					// Current EMI have to be entered					
					int Current_EMI = s.nextInt();
					
					// Calculated Permissible EMI 
					int Permissible_EMI = Net_Disposable_Income - Current_EMI;
					
					System.out.println("Your permissible EMI is : "+Permissible_EMI);
				}
				break;

				

			case "trading":
				
				//If profit margin is greater than or equal to 15 for Trading, it'll consider as 15%			
				if (Profit_margin_Declared / divide >= max_Trading_Percent / divide) {

					// Net monthly income formula (A*Min(C,D))/12					
					double net_Income_Monthly = ((Annual_Turnover * Math.min(max_Trading_Percent / divide, Profit_margin_Declared / divide)) / 12);

					//Profit margin declared
					System.out.println("Profit margin declared is "+Math.min(max_Trading_Percent / divide, Profit_margin_Declared / divide));				
					
					//Calculated Net Income Monthly				
					System.out.println("Calculated Net Income Monthly is "+net_Income_Monthly);				
									
					// Net disposable income formula E(fourtylacs_to_onehundredLacs) * E1(net_Income_Monthly)				
					int Net_Disposable_Income = (int) (net_Income_Monthly * fourtylacs_to_onehundredLacs / divide);

					// Consolidated Net disposable income				
					System.out.println("Your Net disposable income is  "+Net_Disposable_Income);	
					
					System.out.println("Enter the Current EMI : ");				
					
					// Current EMI have to be entered					
					int Current_EMI = s.nextInt();
					
					// Calculated Permissible EMI 
					int Permissible_EMI = Net_Disposable_Income - Current_EMI;
					
					System.out.println("Your permissible EMI is : "+Permissible_EMI);
				}

				//If profit margin is lower than 15 for Trading, it'll consider as entered lower value 			
				else if (Profit_margin_Declared/divide < max_Trading_Percent/divide) {

					// Net monthly income formula (A*Min(C,D))/12
					double net_Income_Monthly = ((Annual_Turnover * Math.min(max_Trading_Percent/divide, Profit_margin_Declared/divide)) / 12);

					//Calculated Net Income Monthly				
					System.out.println("Calculated Net Income Monthly"+net_Income_Monthly);				
									
					// Net disposable income formula E(fourtylacs_to_onehundredLacs) * E1(net_Income_Monthly)
					int Net_Disposable_Income = (int) (net_Income_Monthly * fourtylacs_to_onehundredLacs / divide);

					// Consolidated Net disposable income				
					System.out.println("Your Net disposable income is  "+Net_Disposable_Income);	
					
					System.out.println("Enter the Current EMI : ");				
					
					// Current EMI have to be entered					
					int Current_EMI = s.nextInt();
					
					// Calculated Permissible EMI 
					int Permissible_EMI = Net_Disposable_Income - Current_EMI;
					
					System.out.println("Your permissible EMI is : "+Permissible_EMI);
				}
				break;
			}
			
			

		} 
		
		
		
//***********************************************Annual_Turnover is 100<=300 lacs*******************************************************************		
		
		
		// If Annual_Turnover is 100<=300 lacs
		else if (b <= Annual_Turnover && c >= Annual_Turnover) {

			//Foir is 55%			
			System.out.println("Foir is "+onehundredLacs_to_threehundredLacs + "%");
			
			System.out.println("Please enter Nature Of Business : ");
			
			//Nature of business to be entered				
			String NOB = s.next();
			
			System.out.println("User choosen NOB is "+NOB);
			
			switch (NOB.toLowerCase()) {
			
			case "manufacturing":
				
				//If profit margin is greater than or equal to 15 for manufacturing, it'll consider as 15%			
				if (Profit_margin_Declared / divide >= max_Manufacturing_Percent / divide) {

					// Net monthly income formula (A*Min(C,D))/12					
					double net_Income_Monthly = ((Annual_Turnover * Math.min(max_Manufacturing_Percent / divide, Profit_margin_Declared / divide)) / 12);

					//Calculated Net Income Monthly				
					System.out.println("Calculated Net Income Monthly"+net_Income_Monthly);				
									
					// Net disposable income formula E(fourtylacs_to_onehundredLacs) * E1(net_Income_Monthly)				
					int Net_Disposable_Income = (int) (net_Income_Monthly * onehundredLacs_to_threehundredLacs / divide);

					// Consolidated Net disposable income				
					System.out.println("Your Net disposable income is  "+Net_Disposable_Income);	
					
					System.out.println("Enter the Current EMI : ");				
					
					// Current EMI have to be entered					
					int Current_EMI = s.nextInt();
					
					// Calculated Permissible EMI 
					int Permissible_EMI = Net_Disposable_Income - Current_EMI;
					
					System.out.println("Your permissible EMI is : "+Permissible_EMI);
					
				}
				
				
				//If profit margin is lower than 15 for manufacturing, it'll consider as entered lower value 			
				else if (Profit_margin_Declared/divide < max_Manufacturing_Percent/divide) {
					
					// Net monthly income formula (A*Min(C,D))/12
					double net_Income_Monthly = ((Annual_Turnover * Math.min(max_Manufacturing_Percent/divide, Profit_margin_Declared/divide)) / 12);

					//Calculated Net Income Monthly				
					System.out.println("Calculated Net Income Monthly"+net_Income_Monthly);				
					
					// Net disposable income formula E(fourtylacs_to_onehundredLacs) * E1(net_Income_Monthly)
					int Net_Disposable_Income = (int) (net_Income_Monthly * onehundredLacs_to_threehundredLacs / divide);

					// Consolidated Net disposable income				
					System.out.println("Your Net disposable income is  "+Net_Disposable_Income);	
					
					System.out.println("Enter the Current EMI : ");				
					
					// Current EMI have to be entered					
					int Current_EMI = s.nextInt();
					
					// Calculated Permissible EMI 
					int Permissible_EMI = Net_Disposable_Income - Current_EMI;
					
					System.out.println("Your permissible EMI is : "+Permissible_EMI);
				}
				break;
			
			case "service" :
				
				//If profit margin is greater than or equal to 15 for Service , it'll consider as 17%			
				if (Profit_margin_Declared / divide >= max_Service_Percent / divide) {

					// Net monthly income formula (A*Min(C,D))/12					
					double net_Income_Monthly = ((Annual_Turnover * Math.min(max_Service_Percent / divide, Profit_margin_Declared / divide)) / 12);

					//Calculated Net Income Monthly				
					System.out.println("Calculated Net Income Monthly"+net_Income_Monthly);				
									
					// Net disposable income formula E(fourtylacs_to_onehundredLacs) * E1(net_Income_Monthly)				
					int Net_Disposable_Income = (int) (net_Income_Monthly * onehundredLacs_to_threehundredLacs / divide);

					// Consolidated Net disposable income				
					System.out.println("Your Net disposable income is  "+Net_Disposable_Income);	
					
					System.out.println("Enter the Current EMI : ");				
					
					// Current EMI have to be entered					
					int Current_EMI = s.nextInt();
					
					// Calculated Permissible EMI 
					int Permissible_EMI = Net_Disposable_Income - Current_EMI;
					
					System.out.println("Your permissible EMI is : "+Permissible_EMI);
					
				}
				
				
				//If profit margin is lower than 15 for Service, it'll consider as entered lower value 			
				else if (Profit_margin_Declared/divide < max_Service_Percent/divide) {
					
					// Net monthly income formula (A*Min(C,D))/12
					double net_Income_Monthly = ((Annual_Turnover * Math.min(max_Service_Percent/divide, Profit_margin_Declared/divide)) / 12);

					//Calculated Net Income Monthly				
					System.out.println("Calculated Net Income Monthly"+net_Income_Monthly);				
					
					// Net disposable income formula E(fourtylacs_to_onehundredLacs) * E1(net_Income_Monthly)
					int Net_Disposable_Income = (int) (net_Income_Monthly * onehundredLacs_to_threehundredLacs / divide);

					// Consolidated Net disposable income				
					System.out.println("Your Net disposable income is  "+Net_Disposable_Income);	
					
					System.out.println("Enter the Current EMI : ");				
					
					// Current EMI have to be entered					
					int Current_EMI = s.nextInt();
					
					// Calculated Permissible EMI 
					int Permissible_EMI = Net_Disposable_Income - Current_EMI;
					
					System.out.println("Your permissible EMI is : "+Permissible_EMI);
				}
				
				break;
			
			case "trading":
			
				//If profit margin is greater than or equal to 15 for Trading, it'll consider as 15%			
				if (Profit_margin_Declared / divide >= max_Trading_Percent / divide) {

					// Net monthly income formula (A*Min(C,D))/12					
					double net_Income_Monthly = ((Annual_Turnover * Math.min(max_Trading_Percent / divide, Profit_margin_Declared / divide)) / 12);

					//Profit margin declared
					System.out.println("Profit margin declared is "+Math.min(max_Trading_Percent / divide, Profit_margin_Declared / divide));				
					
					//Calculated Net Income Monthly				
					System.out.println("Calculated Net Income Monthly is "+net_Income_Monthly);				
									
					// Net disposable income formula E(fourtylacs_to_onehundredLacs) * E1(net_Income_Monthly)				
					int Net_Disposable_Income = (int) (net_Income_Monthly * onehundredLacs_to_threehundredLacs / divide);

					// Consolidated Net disposable income				
					System.out.println("Your Net disposable income is  "+Net_Disposable_Income);	
					
					System.out.println("Enter the Current EMI : ");				
					
					// Current EMI have to be entered					
					int Current_EMI = s.nextInt();
					
					// Calculated Permissible EMI 
					int Permissible_EMI = Net_Disposable_Income - Current_EMI;
					
					System.out.println("Your permissible EMI is : "+Permissible_EMI);
					
				}

				//If profit margin is lower than 15 for trading, it'll consider as entered lower value 			
				else if (Profit_margin_Declared/divide < max_Trading_Percent/divide) {

					// Net monthly income formula (A*Min(C,D))/12
					double net_Income_Monthly = ((Annual_Turnover * Math.min(max_Trading_Percent/divide, Profit_margin_Declared/divide)) / 12);

					//Calculated Net Income Monthly				
					System.out.println("Calculated Net Income Monthly"+net_Income_Monthly);				
									
					// Net disposable income formula E(fourtylacs_to_onehundredLacs) * E1(net_Income_Monthly)
					int Net_Disposable_Income = (int) (net_Income_Monthly * onehundredLacs_to_threehundredLacs / divide);

					// Consolidated Net disposable income				
					System.out.println("Your Net disposable income is  "+Net_Disposable_Income);	
					
					System.out.println("Enter the Current EMI : ");				
					
					// Current EMI have to be entered					
					int Current_EMI = s.nextInt();
					
					// Calculated Permissible EMI 
					int Permissible_EMI = Net_Disposable_Income - Current_EMI;
					
					System.out.println("Your permissible EMI is : "+Permissible_EMI);
				}

				break;
		}
		}
		
//******************************************************Annual_Turnover is <300 lacs*******************************************************************		
		
		
		// If Annual_Turnover is <300 lacs
		else if (Annual_Turnover > c) {

			//Foir is 60%			
			System.out.println("Foir is"+above_threehundredLacs + "%");
			
			System.out.println("Please enter Nature Of Business : ");
			
			//Nature of business to be entered				
			String NOB = s.next();
			
			System.out.println("User choosen NOB is "+NOB);
			
			switch (NOB.toLowerCase()) {
			
			case "manufacturing":
			
				//If profit margin is greater than or equal to 15 for manufacturing, it'll consider as 15%			
				if (Profit_margin_Declared / divide >= max_Manufacturing_Percent / divide) {

					// Net monthly income formula (A*Min(C,D))/12					
					double net_Income_Monthly = ((Annual_Turnover * Math.min(max_Manufacturing_Percent / divide, Profit_margin_Declared / divide)) / 12);

					//Calculated Net Income Monthly				
					System.out.println("Calculated Net Income Monthly"+net_Income_Monthly);				
									
					// Net disposable income formula E(fourtylacs_to_onehundredLacs) * E1(net_Income_Monthly)				
					int Net_Disposable_Income = (int) (net_Income_Monthly * above_threehundredLacs / divide);

					// Consolidated Net disposable income				
					System.out.println("Your Net disposable income is  "+Net_Disposable_Income);	
					
					System.out.println("Enter the Current EMI : ");				
					
					// Current EMI have to be entered					
					int Current_EMI = s.nextInt();
					
					// Calculated Permissible EMI 
					int Permissible_EMI = Net_Disposable_Income - Current_EMI;
					
					System.out.println("Your permissible EMI is : "+Permissible_EMI);
					
				}

				//If profit margin is lower than 15 for manufacturing, it'll consider as entered lower value 			
				else if (Profit_margin_Declared/divide < max_Manufacturing_Percent/divide) {

					// Net monthly income formula (A*Min(C,D))/12
					double net_Income_Monthly = ((Annual_Turnover * Math.min(max_Manufacturing_Percent/divide, Profit_margin_Declared/divide)) / 12);

					//Calculated Net Income Monthly				
					System.out.println("Calculated Net Income Monthly"+net_Income_Monthly);				
									
					// Net disposable income formula E(above_threehundredLacs) * E1(net_Income_Monthly)
					int Net_Disposable_Income = (int) (net_Income_Monthly * above_threehundredLacs / divide);

					// Consolidated Net disposable income				
					System.out.println("Your Net disposable income is  "+Net_Disposable_Income);	
					
					System.out.println("Enter the Current EMI : ");				
					
					// Current EMI have to be entered					
					int Current_EMI = s.nextInt();
					
					// Calculated Permissible EMI 
					int Permissible_EMI = Net_Disposable_Income - Current_EMI;
					
					System.out.println("Your permissible EMI is : "+Permissible_EMI);
				}
				
				break;
			
				
				
			case "service":
				
				//If profit margin is greater than or equal to 15 for Service, it'll consider as 15%			
				if (Profit_margin_Declared / divide >= max_Service_Percent / divide) {

					// Net monthly income formula (A*Min(C,D))/12					
					double net_Income_Monthly = ((Annual_Turnover * Math.min(max_Service_Percent / divide, Profit_margin_Declared / divide)) / 12);

					//Profit margin declared
					System.out.println("Profit margin declared is "+Math.min(max_Service_Percent / divide, Profit_margin_Declared / divide));				
					
					//Calculated Net Income Monthly				
					System.out.println("Calculated Net Income Monthly is "+net_Income_Monthly);				
									
					// Net disposable income formula E(above_threehundredLacs) * E1(net_Income_Monthly)				
					int Net_Disposable_Income = (int) (net_Income_Monthly * above_threehundredLacs / divide);

					// Consolidated Net disposable income				
					System.out.println("Your Net disposable income is  "+Net_Disposable_Income);	
					
					System.out.println("Enter the Current EMI : ");				
					
					// Current EMI have to be entered					
					int Current_EMI = s.nextInt();
					
					// Calculated Permissible EMI 
					int Permissible_EMI = Net_Disposable_Income - Current_EMI;
					
					System.out.println("Your permissible EMI is : "+Permissible_EMI);
				}

				//If profit margin is lower than 15 for service, it'll consider as entered lower value 			
				else if (Profit_margin_Declared/divide < max_Service_Percent/divide) {

					// Net monthly income formula (A*Min(C,D))/12
					double net_Income_Monthly = ((Annual_Turnover * Math.min(max_Service_Percent/divide, Profit_margin_Declared/divide)) / 12);

					//Calculated Net Income Monthly				
					System.out.println("Calculated Net Income Monthly"+net_Income_Monthly);				
									
					// Net disposable income formula E(above_threehundredLacs) * E1(net_Income_Monthly)
					int Net_Disposable_Income = (int) (net_Income_Monthly * above_threehundredLacs / divide);

					// Consolidated Net disposable income				
					System.out.println("Your Net disposable income is  "+Net_Disposable_Income);	
					
					System.out.println("Enter the Current EMI : ");				
					
					// Current EMI have to be entered					
					int Current_EMI = s.nextInt();
					
					// Calculated Permissible EMI 
					int Permissible_EMI = Net_Disposable_Income - Current_EMI;
					
					System.out.println("Your permissible EMI is : "+Permissible_EMI);
				}
				break;

				

			case "trading":
				
				//If profit margin is greater than or equal to 15 for Trading, it'll consider as 15%			
				if (Profit_margin_Declared / divide >= max_Trading_Percent / divide) {

					// Net monthly income formula (A*Min(C,D))/12					
					double net_Income_Monthly = ((Annual_Turnover * Math.min(max_Trading_Percent / divide, Profit_margin_Declared / divide)) / 12);

					//Profit margin declared
					System.out.println("Profit margin declared is "+Math.min(max_Trading_Percent / divide, Profit_margin_Declared / divide));				
					
					//Calculated Net Income Monthly				
					System.out.println("Calculated Net Income Monthly is "+net_Income_Monthly);				
									
					// Net disposable income formula E(above_threehundredLacs) * E1(net_Income_Monthly)				
					int Net_Disposable_Income = (int) (net_Income_Monthly * above_threehundredLacs / divide);

					// Consolidated Net disposable income				
					System.out.println("Your Net disposable income is  "+Net_Disposable_Income);	
					
					System.out.println("Enter the Current EMI : ");				
					
					// Current EMI have to be entered					
					int Current_EMI = s.nextInt();
					
					// Calculated Permissible EMI 
					int Permissible_EMI = Net_Disposable_Income - Current_EMI;
					
					System.out.println("Your permissible EMI is : "+Permissible_EMI);
					
				}

				//If profit margin is lower than 15 for trading, it'll consider as entered lower value 			
				else if (Profit_margin_Declared/divide < max_Trading_Percent/divide) {

					// Net monthly income formula (A*Min(C,D))/12
					double net_Income_Monthly = ((Annual_Turnover * Math.min(max_Trading_Percent/divide, Profit_margin_Declared/divide)) / 12);

					//Calculated Net Income Monthly				
					System.out.println("Calculated Net Income Monthly"+net_Income_Monthly);				
									
					// Net disposable income formula E(above_threehundredLacs) * E1(net_Income_Monthly)
					int Net_Disposable_Income = (int) (net_Income_Monthly * above_threehundredLacs / divide);

					// Consolidated Net disposable income				
					System.out.println("Your Net disposable income is  "+Net_Disposable_Income);	
					
					System.out.println("Enter the Current EMI : ");				
					
					// Current EMI have to be entered					
					int Current_EMI = s.nextInt();
					
					// Calculated Permissible EMI 
					int Permissible_EMI = Net_Disposable_Income - Current_EMI;
					
					System.out.println("Your permissible EMI is : "+Permissible_EMI);
				}
				break;
			
		}

		}
		
		else {
			
			System.out.println("User entered Annual turn over is "+Annual_Turnover+" lower than 40,00,000");
			
		}
		
		
	}
	
	

}
