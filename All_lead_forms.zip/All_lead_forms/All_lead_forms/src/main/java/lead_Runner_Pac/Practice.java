package lead_Runner_Pac;

import java.util.ArrayList;
import java.util.Iterator;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pre_Execution.Business_loan_Execution;
import Pre_Execution.Commercial_Execution;
import all_Xpaths.Business_Xpaths;
import common_Package.BaseClass;
import excel_Package.Excel_Utils;
import groovyjarjarantlr4.v4.parse.ANTLRParser.exceptionGroup_return;

public class Practice extends BaseClass {

	@BeforeTest
	public static void beforeTest() {

		compatible_Browser();

		initElements();

	}

	@DataProvider
	public static Iterator<Object[]> getTestData() {
		ArrayList<Object[]> dataFromExcel = Excel_Utils.getDataFromexcel();
		return dataFromExcel.iterator();
	}

	@Test(dataProvider = "getTestData", priority = 1)
	public static void Business_loan_LandingScreen(String INDEX, String Page_URL, String Leads, String cus_name,
			String cus_mobile, String cus_email, String otp_input_field, String Year, String Month, String Date,
			String loan_Amount, String pincode, String Bussiness_nature, String Pan_no, String Gender,
			String Marital_Status, String Residence_Type, String Years_living, String Business_name,
			String Business_type, String Business_premises, String Type_of_collateral, String Year_of_business,
			String Business_Pincode, String Annual_Turnover, String Business_Proof, String Gst, String ID_proofdoc,
			String Addres_proofdoc, String BusinessIncomeDoc) throws Exception {

		Commercial_Execution.SFL_Website(INDEX, Page_URL);

		if (Leads.equals("Business_Loan")) {

			Business_loan_Execution.Business_loan_Landing_Page(cus_name, cus_mobile, cus_email);

		}

	}

	@Test(dataProvider = "getTestData", priority = 2)
	public static void Business_loan_OTP_Validation(String INDEX, String Page_URL, String Leads, String cus_name,
			String cus_mobile, String cus_email, String otp_input_field, String Year, String Month, String Date,
			String loan_Amount, String pincode, String Bussiness_nature, String Pan_no, String Gender,
			String Marital_Status, String Residence_Type, String Years_living, String Business_name,
			String Business_type, String Business_premises, String Type_of_collateral, String Year_of_business,
			String Business_Pincode, String Annual_Turnover, String Business_Proof, String Gst, String ID_proofdoc,
			String Addres_proofdoc, String BusinessIncomeDoc) throws Exception {

		Business_loan_Execution.Otp_Pop_Up(otp_input_field);

	}

	@Test(dataProvider = "getTestData", priority = 3)
	public static void Business_Date_of_Birth_Validation(String INDEX, String Page_URL, String Leads, String cus_name,
			String cus_mobile, String cus_email, String otp_input_field, String Year, String Month, String Date,
			String loan_Amount, String pincode, String Bussiness_nature, String Pan_no, String Gender,
			String Marital_Status, String Residence_Type, String Years_living, String Business_name,
			String Business_type, String Business_premises, String Type_of_collateral, String Year_of_business,
			String Business_Pincode, String Annual_Turnover, String Business_Proof, String Gst, String ID_proofdoc,
			String Addres_proofdoc, String BusinessIncomeDoc) throws Exception {

		Business_loan_Execution.DOB(Year, Month, Date);

	}

	@Test(dataProvider = "getTestData", priority = 4)
	public static void Business_loan_Details(String INDEX, String Page_URL, String Leads, String cus_name,
			String cus_mobile, String cus_email, String otp_input_field, String Year, String Month, String Date,
			String loan_Amount, String pincode, String Bussiness_nature, String Pan_no, String Gender,
			String Marital_Status, String Residence_Type, String Years_living, String Business_name,
			String Business_type, String Business_premises, String Type_of_collateral, String Year_of_business,
			String Business_Pincode, String Annual_Turnover, String Business_Proof, String Gst, String ID_proofdoc,
			String Addres_proofdoc, String BusinessIncomeDoc) throws Exception {

		// Business_loan_Execution.Otp_Pop_Up(otp_input_field);
		Business_loan_Execution.loan_details(loan_Amount, pincode, Bussiness_nature, INDEX);

	}

	@Test(dataProvider = "getTestData", priority = 5)
	public static void congragulations(String INDEX, String Page_URL, String Leads, String cus_name, String cus_mobile,
			String cus_email, String otp_input_field, String Year, String Month, String Date, String loan_Amount,
			String pincode, String Bussiness_nature, String Pan_no, String Gender, String Marital_Status,
			String Residence_Type, String Years_living, String Business_name, String Business_type,
			String Business_premises, String Type_of_collateral, String Year_of_business, String Business_Pincode,
			String Annual_Turnover, String Business_Proof, String Gst, String ID_proofdoc, String Addres_proofdoc,
			String BusinessIncomeDoc) throws Exception {

		Thread.sleep(5000);

//			String text2 = driver.findElement(By.xpath("//h4[text()='Congratulations']")).getText();

		for (int i = 0; i < 2; i++) {

			boolean expvalue = driver.findElement(By.xpath("//h4[text()='Congratulations']")).isDisplayed();

			if (i == 0) {

				System.out.println("working");

				Assert.assertTrue(expvalue);

			} else {

				System.out.println("not working");

				try {
					if (displayed(Business_Xpaths.getInstance().getbusiness_Stage_step1())) {

						Business_loan_Execution.personal_details(Pan_no, Gender, Marital_Status, Residence_Type,
								Years_living);
					} else {
						System.out.println("Business_loan_Personal_details - Executed");
					}
				} catch (InterruptedException e) {
					throw new SkipException("Skipping this exception");
				}

				try {
					if (displayed(Business_Xpaths.getInstance().getbusiness_Stage_step2())) {

						Business_loan_Execution.Business_loan_Residental_details(Residence_Type, Years_living);

					} else {
						System.out.println("Business_loan_Residental_details- Executed");
						throw new SkipException("Skipping this exception");
					}
				} catch (Exception e) {
					throw new SkipException("Skipping this exception");
				}
				try {
					if (displayed(Business_Xpaths.getInstance().getbusiness_Stage_step3())) {

						Business_loan_Execution.business_informations(Business_name, Business_type, Business_premises,
								Type_of_collateral, Year_of_business, Business_Pincode, Annual_Turnover, Business_Proof,
								Gst);

					} else {
						System.out.println("Business_loan_Information- Executed");
						throw new SkipException("Skipping this exception");
					}
				} catch (Exception e) {
					throw new SkipException("Skipping this exception");
				}

				try {
					Thread.sleep(3000);
//						driver.findElement(By.xpath("//*[@id=\"fd-upload\"]/form/div/div[1]/div/div[1]/div/div[1]/input"))
//								.sendKeys("C:/Users/e078/Pictures/flowerpng.png");

					Business_loan_Execution.businessdocument_upload_process(ID_proofdoc, Addres_proofdoc,
							BusinessIncomeDoc);

					Thread.sleep(3000);
					driver.findElement(By.xpath("//*[@id=\"fd-upload\"]/form/div/div[1]/div/div[2]/div/div[1]/input"))
							.sendKeys("C:/Users/e078/Pictures/flowerpng.png");

					Thread.sleep(3000);
					driver.findElement(By.xpath("//*[@id=\"fd-upload\"]/form/div/div[1]/div/div[3]/div/div[1]/input"))
							.sendKeys("C:/Users/e078/Pictures/flowerpng.png");

					Click(Business_Xpaths.getInstance().getbusiness_Stage3_submit());
				} catch (InterruptedException e) {

					e.printStackTrace();
				}

				Assert.assertFalse(expvalue);

			}
		}

	}

}
