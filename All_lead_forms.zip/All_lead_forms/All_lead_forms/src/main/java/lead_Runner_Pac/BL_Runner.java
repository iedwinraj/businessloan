package lead_Runner_Pac;

import java.util.ArrayList;
import java.util.Iterator;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pre_Execution.Business_loan_Execution;
import Pre_Execution.Challan_Execution;
import Pre_Execution.Commercial_Execution;
import Pre_Execution.Construction_Execution;
import Pre_Execution.Fuel_Execution;
import Pre_Execution.Goods_Execution;
import Pre_Execution.Passenger_Execution;
import Pre_Execution.Repair_Execution;
import Pre_Execution.Tax_Execution;
import Pre_Execution.Toll_Execution;
import Pre_Execution.Tractor_Execution;
import Pre_Execution.Tyre_Execution;
import Pre_Execution.Vehicle_Insurance_Execution;
import Pre_Execution.Working_Capital_Execution;
import all_Xpaths.Business_Xpaths;
import common_Package.BaseClass;
import common_Package.StagesConstant;
import excel_Package.Excel_Utils;

public class BL_Runner extends BaseClass {

	@BeforeTest
	public static void beforeTest() {

		compatible_Browser();

		initElements();

	}

	@DataProvider
	public static Iterator<Object[]> getTestData() {
		ArrayList<Object[]> dataFromExcel = Excel_Utils.getDataFromexcel();
		return dataFromExcel.iterator();
	}

	@Test(dataProvider = "getTestData", priority = 1)
	public static void Business_loan_LandingScreen(String INDEX, String Page_URL, String Leads, String cus_name,
			String cus_mobile, String cus_email, String otp_input_field, String Year, String Month, String Date,
			String loan_Amount, String pincode, String Bussiness_nature, String Pan_no, String Gender,
			String Marital_Status, String Residence_Type, String Years_living, String Business_name,
			String Business_type, String Business_premises, String Type_of_collateral, String Year_of_business,
			String Business_Pincode, String Annual_Turnover, String Business_Proof, String Gst, String ID_proofdoc,
			String Addres_proofdoc, String BusinessIncomeDoc) throws Exception {

		Business_loan_Execution.SFL_Website(INDEX, Page_URL);

		if (Leads.equals("Business_Loan")) {

			System.out.println(cus_name);
			System.out.println(cus_mobile);
			System.out.println(cus_email);

			Business_loan_Execution.Business_loan_Landing_Page(cus_name, cus_mobile, cus_email);

			Business_loan_Execution.Otp_Pop_Up(otp_input_field);

			Business_loan_Execution.DOB(Year, Month, Date);

			Business_loan_Execution.loan_details(loan_Amount, pincode, Bussiness_nature, INDEX);
			Thread.sleep(3000);
			
			
			//WebElement Stage1conatent = driver.findElement(By.xpath("//h3[contains(text(),'Personal Details')]"));
			//System.out.println(Stage1conatent.getText());
			try {
				String Stage1 = Business_Xpaths.getInstance().getbusiness_Stage_step1().getText();
				if (StagesConstant.Constants.STAGE1_PERSONAL_DETAILS
						.equalsIgnoreCase(Stage1)) {
					Business_loan_Execution.personal_details(Pan_no, Gender, Marital_Status, Residence_Type, Years_living);
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				System.out.println("STAGE1_PERSONAL_DETAILS - STEPS SKIPPED");
			}
			
			Thread.sleep(5000);
			try {
				if (StagesConstant.Constants.STAGE2_RESIDENTIAL_DETAILS
						.equalsIgnoreCase(Business_Xpaths.getInstance().getbusiness_Stage_step2().getText())) {
					Business_loan_Execution.Business_loan_Residental_details(Residence_Type, Years_living);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				System.out.println("STAGE2_RESIDENTIAL_DETAILS - STEPS SKIPPED");

			}
			

			

			//Business_loan_Execution.business_informations(Business_name, Business_type, Business_premises,
			//		Type_of_collateral, Year_of_business, Business_Pincode, Annual_Turnover, Business_Proof, Gst);

			//Business_loan_Execution.businessdocument_upload_process(ID_proofdoc, Addres_proofdoc, BusinessIncomeDoc);

		}

	}

	@AfterTest
	public static void tearDown() {

		quitBrowser();

	}

}
