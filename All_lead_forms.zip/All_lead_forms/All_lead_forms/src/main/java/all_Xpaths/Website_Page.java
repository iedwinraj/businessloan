package all_Xpaths;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Website_Page {

	private static Website_Page xpathsPageInstance;

	private Website_Page() {

	}

	public static Website_Page getInstance() {
		if (xpathsPageInstance == null) {
			xpathsPageInstance = new Website_Page();
		}
		return xpathsPageInstance;
	}

	// -----------------------/---------------HEADER-------------------/-----------------------------------

	@FindBy(xpath = "/html/body/app-root/app-header/header/section[2]/div/div/div[2]/p/span[1]")
	private WebElement headerLoan;

	public WebElement getHeaderLoan() {
		return headerLoan;
	}

//---------------------------/-----------------Commercial vehicle loans-------------/-------------//

	@FindBy(id = "main_nav_cvl")
	private WebElement cmv_Loans;

	public WebElement getCmv_Loans() {
		return cmv_Loans;
	}

//---------------------------/-----------------commercial-goods-vehicle-finance-------------/-------------//

	@FindBy(xpath = "//*[@id=\"main_nav_cgvf\"]")
	private WebElement cmgv_Loans;

	public WebElement getCmgv_Loans() {
		return cmgv_Loans;
	}

//---------------------------/-----------------passenger-commercial-vehicle-finance-------------/-------------//		

	@FindBy(xpath = "//*[@id=\"main_nav_pcvf\"]")
	private WebElement pcvf_loans;

	public WebElement getPcvf_loans() {
		return pcvf_loans;
	}

//---------------------------/-----------------tractor-farm-equipment-finance-------------/-------------//		

	@FindBy(xpath = "//*[@id=\"main_nav_tractor\"]")
	private WebElement trfaeqf_loans;

	public WebElement getTrfaeqf_loans() {
		return trfaeqf_loans;
	}

//---------------------------/-----------------construction-equipment-finance-------------/-------------//			

	@FindBy(xpath = "//*[@id=\"main_nav_construction\"]")
	private WebElement coneqf_Loans;

	public WebElement getConeqf_Loans() {
		return coneqf_Loans;
	}

//---------------------------/-----------------Working Capital Loans-------------/-------------//			

	@FindBy(xpath = "//*[@id=\"main_nav_wcl\"]")
	private WebElement worcap_Loans;

	public WebElement getWorcap_Loans() {
		return worcap_Loans;
	}

//---------------------------/----------------Vehicle Insurance Finance-------------/-------------//			

	@FindBy(xpath = "//*[@id=\"main_nav_vif\"]")
	private WebElement vehInsFi_Loans;

	public WebElement getVehInsFi_Loans() {
		return vehInsFi_Loans;
	}

//---------------------------/----------------tyre_finance_Loans-------------/-------------//	

	@FindBy(xpath = "//*[@id=\"main_nav_tyre\"]")
	private WebElement tyre_finance_Loans;

	public WebElement getTyre_finance_Loans() {
		return tyre_finance_Loans;
	}

//---------------------------/----------------tax_finance_Loans-------------/-------------//			

	@FindBy(id = "main_nav_tax")
	private WebElement tax_finance_Loans;

	public WebElement getTax_finance_Loans() {
		return tax_finance_Loans;
	}

//---------------------------/----------------main_nav_toll_Loans-------------/-------------//		

	@FindBy(id = "main_nav_toll")
	private WebElement toll_finance;

	public WebElement getToll_finance() {
		return toll_finance;
	}

//---------------------------/----------------main_nav_repair_Loans-------------/-------------//		

	@FindBy(id = "main_nav_repair")
	private WebElement repair_Loans;

	public WebElement getRepair_Loans() {
		return repair_Loans;
	}

//---------------------------/----------------main_nav_fuel_finance_Loans-------------/-------------//	

	@FindBy(id = "main_nav_fuel_finance")
	private WebElement fuel_finance_Loans;

	public WebElement getFuel_finance_Loans() {
		return fuel_finance_Loans;
	}

//---------------------------/----------------challan_discounting_Loans-------------/-------------//	

	@FindBy(id = "main_nav_cd")
	private WebElement challan_disc_Loans;

	public WebElement getChallan_disc_Loans() {
		return challan_disc_Loans;
	}

//---------------------------/----------------business_Loans-------------/-------------//	

	@FindBy(id = "main_nav_bl")
	private WebElement business_Loans;

	public WebElement getBusiness_Loans() {
		return business_Loans;
	}
//------------------------------/---------------- Congragulations ----------------------//

	@FindBy(xpath = "//h6[text()='Request Already Registered']")
	private WebElement req_submitted;

	public WebElement getReq_submitted() {
		return req_submitted;
	}

}
