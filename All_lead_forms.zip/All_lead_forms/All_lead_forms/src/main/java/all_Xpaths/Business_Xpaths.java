package all_Xpaths;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class Business_Xpaths {

	private static Business_Xpaths xpathsPageInstance;

	private Business_Xpaths() {

	}

	public static Business_Xpaths getInstance() {
		if (xpathsPageInstance == null) {
			xpathsPageInstance = new Business_Xpaths();
		}
		return xpathsPageInstance;
	}

	public WebElement getbusiness_cus_name() {
		return business_cus_name;
	}

	public WebElement getbusiness_cus_mobile() {
		return business_cus_mobile;
	}

	public WebElement getbusiness_cus_email() {
		return business_cus_email;
	}

	public WebElement getbusiness_pf_apply_btn() {
		return business_pf_apply_btn;
	}

	public WebElement getbusiness_otp_field() {
		return business_otp_field;
	}

	public WebElement getbusiness_otpVerifybtn() {
		return business_otpVerifybtn;
	}

	public WebElement getbusiness_loan_dob() {
		return business_loan_dob;
	}

	public WebElement getbusiness_calender_elobration() {
		return business_calender_elobration;
	}

	public WebElement getbusiness_cus_loanAmount() {
		return business_cus_loanAmount;
	}

	public WebElement getbusiness_cus_pincode2() {
		return business_cus_pincode2;
	}

	public WebElement getbusiness_pf_apply_btn1() {
		return business_pf_apply_btn1;
	}

	public WebElement getbusiness_nature() {
		return business_nature;
	}

	public WebElement getsmeLoan() {
		return business_nature_smeLoan;
	}

	public WebElement gettransportLoan() {
		return business_nature_transportLoan;
	}

	public WebElement getbusiness_cus_pan() {
		return business_cus_pan;
	}

	public WebElement getbusiness_cus_gender() {
		return business_cus_gender;
	}

	public WebElement getbusiness_cus_gender_male() {
		return business_cus_gender_male;
	}

	public WebElement getbusiness_cus_gender_female() {
		return business_cus_gender_female;
	}

	public WebElement getbusiness_cus_gender_others() {
		return business_cus_gender_others;
	}

	public WebElement getbusiness_cus_marital_status() {
		return business_cus_marital_status;
	}

	public WebElement getbusiness_cus_marital_status_single() {
		return business_cus_marital_status_single;
	}

	public WebElement getbusiness_cus_marital_status_married() {
		return business_cus_marital_status_married;
	}

	public WebElement getbusiness_agree_checkbox() {
		return business_agree_checkbox;
	}

	public WebElement getbusiness_stepbtn_1() {
		return business_stepbtn_1;
	}

	public WebElement getbusiness_cus_res() {
		return business_cus_res;
	}

	@CacheLookup
	@FindBy(id = "cus_name")
	private WebElement business_cus_name;

	@FindBy(id = "cus_mobile")
	private WebElement business_cus_mobile;

	@FindBy(id = "cus_email")
	private WebElement business_cus_email;

	@FindBy(id = "pf-apply-btn")
	private WebElement business_pf_apply_btn;

	@FindBy(xpath = "//div[@class='input_field']")
	private WebElement business_otp_field;

	@FindBy(id = "otpVerifybtn")
	private WebElement business_otpVerifybtn;

	@FindBy(id = "loan-dob")
	private WebElement business_loan_dob;

	@FindBy(xpath = "//*[@id=\"mat-datepicker-0\"]/mat-calendar-header/div/div/button[1]")
	private WebElement business_calender_elobration;

	@FindBy(id = "cus_loanAmount")
	private WebElement business_cus_loanAmount;

	@FindBy(id = "cus_pincode2")
	private WebElement business_cus_pincode2;

	@FindBy(id = "pf-apply-btn1")
	private WebElement business_pf_apply_btn1;

	@FindBy(xpath = "//div[@class='input-box p-relative search-box bus-nau focused']")
	private WebElement business_nature;

	@FindBy(xpath = "//li[contains(text(),'SME loan')]")
	private WebElement business_nature_smeLoan;

	@FindBy(xpath = "//li[contains(text(),'Transport Business Loan')]")
	private WebElement business_nature_transportLoan;

	@FindBy(id = "cus_pan")
	private WebElement business_cus_pan;

	@FindBy(id = "cus_gender")
	private WebElement business_cus_gender;

	@FindBy(xpath = "//li[contains(text(),'Male')]")
	private WebElement business_cus_gender_male;

	@FindBy(xpath = "//li[contains(text(),'Female')]")
	private WebElement business_cus_gender_female;

	@FindBy(xpath = "//li[contains(text(),'Others')]")
	private WebElement business_cus_gender_others;

	@FindBy(id = "cus_marital_status")
	private WebElement business_cus_marital_status;

	@FindBy(xpath = "//li[contains(text(),'Single')]")
	private WebElement business_cus_marital_status_single;

	@FindBy(xpath = "//li[contains(text(),'Married')]")
	private WebElement business_cus_marital_status_married;

	@FindBy(xpath = "//span[contains(text(),'I have read and agree to the')]")
	private WebElement business_agree_checkbox;

	@FindBy(id = "stepbtn-1")
	private WebElement business_stepbtn_1;

	@FindBy(id = "cus_res")
	private WebElement business_cus_res;

	// Resident_type
	@FindBy(xpath = "//li[contains(text(),'Owned by self/spouse')]")
	private WebElement business_Res_type_Owned_by_self_spouse;

	public WebElement getbusiness_Res_type_Owned_by_self_spouse() {
		return business_Res_type_Owned_by_self_spouse;
	}

	@FindBy(xpath = "//li[contains(text(),'Owned By Parent/Sibling')]")
	private WebElement business_Res_type_Owned_By_Parent_Sibling;

	public WebElement getbusiness_Res_type_Owned_By_Parent_Sibling() {
		return business_Res_type_Owned_By_Parent_Sibling;
	}

	@FindBy(xpath = "//li[contains(text(),'Rented with Family')]")
	private WebElement business_Res_type_Rented_with_Family;

	public WebElement getbusiness_Res_type_Rented_with_Family() {
		return business_Res_type_Rented_with_Family;
	}

	@FindBy(xpath = "//li[contains(text(),'Rented with Friends')]")
	private WebElement business_Res_type_Rented_with_Friends;

	public WebElement getbusiness_Res_type_Rented_with_Friends() {
		return business_Res_type_Rented_with_Friends;
	}

	@FindBy(xpath = "//li[contains(text(),'Rented Staying Alone')]")
	private WebElement business_Res_type_Rented_Staying_Alone;

	public WebElement getbusiness_Res_type_Rented_Staying_Alone() {
		return business_Res_type_Rented_Staying_Alone;
	}

	@FindBy(xpath = "//li[contains(text(),'Paying Guest')]")
	private WebElement business_Res_type_Paying_Guest;

	public WebElement getbusiness_Res_type_Paying_Guest() {
		return business_Res_type_Paying_Guest;
	}

	@FindBy(xpath = "//li[contains(text(),'Hostel')]")
	private WebElement business_Res_type_Hostel;

	public WebElement getbusiness_Res_type_Hostel() {
		return business_Res_type_Hostel;
	}

	@FindBy(xpath = "//li[contains(text(),'Company Provided')]")
	private WebElement business_Res_type_Company_Provided;

	public WebElement getbusiness_Res_Company_Provided() {
		return business_Res_type_Company_Provided;
	}

	// Years-of-living
	@FindBy(id = "cus_ress")
	private WebElement business_cus_res_live_years;

	public WebElement getbusiness_cus_res_live_years() {
		return business_cus_res_live_years;
	}

	// Years-of-living - options

	@FindBy(xpath = "//li[contains(text(),'<1')]")
	private WebElement business_Liveyear_Lessthanone;

	public WebElement getbusiness_LiveyearLessthan_one() {
		return business_Liveyear_Lessthanone;
	}

	@FindBy(xpath = "//li[contains(text(),'1')]")
	private WebElement business_Liveyear_one;

	public WebElement getbusiness_Liveyear_one() {
		return business_Liveyear_one;
	}

	@FindBy(xpath = "//li[contains(text(),'2')]")
	private WebElement business_Liveyear_two;

	public WebElement getbusiness_Liveyear_two() {
		return business_Liveyear_two;
	}

	@FindBy(xpath = "//li[contains(text(),'3')]")
	private WebElement business_Liveyear_three;

	public WebElement getbusiness_Liveyear_three() {
		return business_Liveyear_three;
	}

	@FindBy(xpath = "//li[contains(text(),'4')]")
	private WebElement business_Liveyear_four;

	public WebElement getbusiness_Liveyear_four() {
		return business_Liveyear_four;
	}

	@FindBy(xpath = "//li[contains(text(),'5')]")
	private WebElement business_Liveyear_five;

	public WebElement getbusiness_Liveyear_five() {
		return business_Liveyear_five;
	}

	@FindBy(xpath = "//li[contains(text(),'>5')]")
	private WebElement business_Liveyear_greaterfive;

	public WebElement getbusiness_Liveyear_Greaterfive() {
		return business_Liveyear_greaterfive;
	}

	// Stage 2 button
	@FindBy(id = "stepbtn-2")
	private WebElement business_stepbtn_2;

	public WebElement getbusiness_stepbtn_2() {
		return business_stepbtn_2;
	}

	// BusinessName id="cus_buss"
	@FindBy(id = "cus_buss")
	private WebElement business_name;

	public WebElement getbusiness_name() {
		return business_name;
	}

	// Business type
	@FindBy(id = "cus_ty")
	private WebElement business_type;

	public WebElement getbusiness_type() {
		return business_type;
	}

	// Business type -options
	@FindBy(xpath = "//li[contains(text(),'Proprietor')]")
	private WebElement business_type_Proprietore;

	public WebElement getbusiness_type_Proprietore() {
		return business_type_Proprietore;
	}

	@FindBy(xpath = "//li[contains(text(),'Partnership')]")
	private WebElement business_type_Partnership;

	public WebElement getbusiness_type_Partnership() {
		return business_type_Partnership;
	}

	@FindBy(xpath = "//li[contains(text(),'Private Limited')]")
	private WebElement business_type_Private_Limited;

	public WebElement getbusiness_type_Private_Limited() {
		return business_type_Private_Limited;
	}

	@FindBy(xpath = "//li[contains(text(),'Limited Company')]")
	private WebElement business_type_Limited_Company;

	public WebElement getbusiness_type_Limited_Company() {
		return business_type_Limited_Company;
	}

	// Business Premises
	@FindBy(id = "cus_bp")
	private WebElement business_premises;

	public WebElement getbusiness_premises() {
		return business_premises;
	}

	// Business Premises -Options
	@FindBy(xpath = "//li[contains(text(),'RCC with Shutter in Residential Area')]")
	private WebElement business_premises_rcc_residential;

	public WebElement getbusiness_premises_rcc_residential() {
		return business_premises_rcc_residential;
	}

	@FindBy(xpath = "//li[contains(text(),'RCC with Shutter in Market')]")
	private WebElement business_premises_rcc_market;

	public WebElement getbusiness_premises_rcc_market() {
		return business_premises_rcc_market;
	}

	@FindBy(xpath = "//li[contains(text(),'Shop in Shopping Complex/ Mall')]")
	private WebElement business_premises_shop_complex_mall;

	public WebElement getbusiness_premises_shop_complex_mall() {
		return business_premises_shop_complex_mall;
	}

	@FindBy(xpath = "//li[contains(text(),'Industrial Office')]")
	private WebElement business_premises_industrial_office;

	public WebElement getbusiness_premises_industrial_office() {
		return business_premises_industrial_office;
	}

	@FindBy(xpath = "//li[contains(text(),'Administrative Office')]")
	private WebElement business_premises_administrative_Office;

	public WebElement getbusiness_premises_administrative_Office() {
		return business_premises_administrative_Office;
	}

	// Business collateral
	@FindBy(id = "cus_tc")
	private WebElement business_collateral;

	public WebElement getbusiness_collateral() {
		return business_collateral;
	}

	@FindBy(xpath = "//li[contains(text(),'Agricultural Collateral')]")
	private WebElement business_collatType_Agricultural_Collateral;

	public WebElement getbusiness_collatType_Agricultural_Collateral() {
		return business_collatType_Agricultural_Collateral;
	}

	@FindBy(xpath = "//li[contains(text(),'Commercial Collateral')]")
	private WebElement business_collatType_Commercial_Collateral;

	public WebElement getbusiness_collatType_Commercial_Collateral() {
		return business_collatType_Commercial_Collateral;
	}

	@FindBy(xpath = "//li[contains(text(),'Residential Collateral')]")
	private WebElement business_collatType_Residential_Collateral;

	public WebElement getbusiness_collatType_Residential_Collateral() {
		return business_collatType_Residential_Collateral;
	}

	@FindBy(xpath = "//li[contains(text(),' No Collateral, No Guarantor')]")
	private WebElement business_collatType_NoCollateral_NoGuarantor;

	public WebElement getbusiness_collatType_NoCollateral_NoGuarantor() {
		return business_collatType_NoCollateral_NoGuarantor;
	}

	@FindBy(xpath = "//li[contains(text(),'Only Guarantor')]")
	private WebElement business_collatType_Only_Guarantor;

	public WebElement getbusiness_collatType_Only_Guarantor() {
		return business_collatType_Only_Guarantor;
	}

	// Years in Business;
	@FindBy(id = "cus_yb")
	private WebElement business_in_Years;

	public WebElement getbusiness_in_Years() {
		return business_in_Years;
	}

	// Years in business options:

	@FindBy(xpath = "//li[contains(text(),'<1')]")
	private WebElement business_Businessin_Lessthanoneyear;

	public WebElement getbusiness_BusinessinLessthan_oneyear() {
		return business_Businessin_Lessthanoneyear;
	}

	@FindBy(xpath = "//li[contains(text(),'1')]")
	private WebElement business_Businessin_oneyear;

	public WebElement getbusiness_Businessin_oneyear() {
		return business_Businessin_oneyear;
	}

	@FindBy(xpath = "//li[contains(text(),'2')]")
	private WebElement business_Businessin_twoyear;

	public WebElement getbusiness_Businessin_twoyear() {
		return business_Businessin_twoyear;
	}

	@FindBy(xpath = "//li[contains(text(),'3')]")
	private WebElement business_Businessin_threeyear;

	public WebElement getbusiness_Businessin_threeyear() {
		return business_Businessin_threeyear;
	}

	@FindBy(xpath = "//li[contains(text(),'4')]")
	private WebElement business_Businessin_fouryear;

	public WebElement getbusiness_Businessin_fouryear() {
		return business_Businessin_fouryear;
	}

	@FindBy(xpath = "//li[contains(text(),'5')]")
	private WebElement business_Businessin_fiveyear;

	public WebElement getbusiness_Businessin_fiveyear() {
		return business_Businessin_fiveyear;
	}

	@FindBy(xpath = "//li[contains(text(),'>5')]")
	private WebElement business_Businessin_greaterfiveyear;

	public WebElement getbusiness_Businessin_Greaterfiveyear() {
		return business_Businessin_greaterfiveyear;
	}

	// Business pincode
	@FindBy(id = "cus_bus")
	private WebElement business_pincode;

	public WebElement getbusiness_pincode() {
		return business_pincode;
	}

	// customer turnouver
	@FindBy(id = "cu_turn")
	private WebElement business_annual_turnover;

	public WebElement getbusiness_annual_turnover() {
		return business_annual_turnover;
	}

	// customer proof of business -yes
	@FindBy(xpath = "//label[@class='myradio__label' and @for='bus-yes']")
	private WebElement business_proof_yes;

	public WebElement getbusiness_proof_yes() {
		return business_proof_yes;
	}

	// customer proof of business -No
	@FindBy(xpath = "//label[@class='myradio__label' and @for='bus-no']")
	private WebElement business_proof_no;

	public WebElement getbusiness_proof_no() {
		return business_proof_no;
	}

	// GST option Yes and NO
	@FindBy(id = "gst-yes2")
	private WebElement business_gst_yes;

	public WebElement getbusiness_gst_yes() {
		return business_gst_yes;
	}

	@FindBy(id = "gst-no2")
	private WebElement business_gst_no;

	public WebElement getbusiness_gst_no() {
		return business_gst_no;
	}

	// Final Submit
	@FindBy(id = "fd-submit")
	private WebElement business_final_submit;

	public WebElement getbusiness_final_submit() {
		return business_final_submit;
	}

	@FindBy(xpath = "//*[@id=\"fd-upload\"]/form/div/div[1]/div/div[1]/div/div[1]/input")
	private WebElement business_id_proof;

	public WebElement getbusiness_id_proof() {
		return business_id_proof;
	}

	// FileUpload_Stage

	@FindBy(xpath = "//h3[text()='Thank you for sharing the information. Our team will be in touch with you shortly.']")
	private WebElement business_FileUpload_Stage;

	public WebElement getbusiness_FileUpload_Stage() {
		return business_FileUpload_Stage;
	}

	// id="per-count"

	@FindBy(id = "per-count")
	private WebElement business_Stage_presentage;

	public WebElement getbusiness_Stage_presentage() {
		return business_Stage_presentage;
	}

	@FindBy(xpath = "//span[text()='1']")
	private WebElement business_Stage_step1;

	public WebElement getbusiness_Stage_step1() {
		return business_Stage_step1;
	}

	@FindBy(xpath = "//span[text()='2']")
	private WebElement business_Stage_step2;

	public WebElement getbusiness_Stage_step2() {
		return business_Stage_step2;
	}

	@FindBy(xpath = "(//span[text()='3'])[3]")
	private WebElement business_Stage_step3;

	public WebElement getbusiness_Stage_step3() {
		return business_Stage_step3;
	}

	@FindBy(xpath = "//span[text()='4']")
	private WebElement business_Stage_step4;

	public WebElement getbusiness_Stage_step4() {
		return business_Stage_step4;
	}

	// Stage3_submit

	@FindBy(id = "stepbtn-3")
	private WebElement business_Stage3_submit;

	public WebElement getbusiness_Stage3_submit() {
		return business_Stage3_submit;
	}
	
	//Stages-Titles
	
	@FindBy(xpath = "//h3[contains(text(),'Personal Details')]")
	private WebElement business_PersonalDetails;

	public WebElement getbusiness_business_PersonalDetails() {
		return business_PersonalDetails;
	}
	
	
		@FindBy(xpath = "//h3[contains(text(),'Residential details')]")
	private WebElement business_ResidentialDetails;

	public WebElement getbusiness_Residential_details() {
		return business_ResidentialDetails;
	}
	
}
