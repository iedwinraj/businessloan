package all_Xpaths;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class Construction_xpaths {
	
	private static Construction_xpaths xpathsPageInstance;

	private Construction_xpaths() {

	}

	public static Construction_xpaths getInstance() {
		if (xpathsPageInstance == null) {
			xpathsPageInstance = new Construction_xpaths();
		}
		return xpathsPageInstance;
	}
	
	
	public WebElement getconstruction_cus_name() {
		return construction_cus_name;
	}

	public WebElement getconstruction_cus_mobile() {
		return construction_cus_mobile;
	}

	public WebElement getconstruction_cus_email() {
		return construction_cus_email;
	}

	public WebElement getconstruction_pf_apply_btn() {
		return construction_pf_apply_btn;
	}

	public WebElement getconstruction_otp_field() {
		return construction_otp_field;
	}

	public WebElement getconstruction_otpVerifybtn() {
		return construction_otpVerifybtn;
	}

	public WebElement getconstruction_loan_dob() {
		return construction_loan_dob;
	}

	public WebElement getconstruction_calender_elobration() {
		return construction_calender_elobration;
	}

	public WebElement getconstruction_cus_loanAmount() {
		return construction_cus_loanAmount;
	}

	public WebElement getconstruction_cus_pincode2() {
		return construction_cus_pincode2;
	}

	public WebElement getconstruction_pf_apply_btn1() {
		return construction_pf_apply_btn1;
	}


	@CacheLookup
	@FindBy(id="cus_name")
	private WebElement construction_cus_name;
	
	@FindBy(id="cus_mobile")
	private WebElement construction_cus_mobile;
	
	@FindBy(id="cus_email")
	private WebElement construction_cus_email;
	
	@FindBy(id="pf-apply-btn")
	private WebElement construction_pf_apply_btn;

	@FindBy(xpath="//div[@class='input_field']")
	private WebElement construction_otp_field;
	
	@FindBy(id="otpVerifybtn")
	private WebElement construction_otpVerifybtn;
	
	@FindBy(id="loan-dob")
	private WebElement construction_loan_dob;
	
	@FindBy(xpath="//*[@id=\"mat-datepicker-0\"]/mat-calendar-header/div/div/button[1]")
	private WebElement construction_calender_elobration;
	
	@FindBy(id="cus_loanAmount")
	private WebElement construction_cus_loanAmount;
	
	@FindBy(id="cus_pincode2")
	private WebElement construction_cus_pincode2;
	
	@FindBy(id="pf-apply-btn1")
	private WebElement construction_pf_apply_btn1;

}
