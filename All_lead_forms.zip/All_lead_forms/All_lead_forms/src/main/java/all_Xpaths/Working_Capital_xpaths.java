package all_Xpaths;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class Working_Capital_xpaths {
	
	private static Working_Capital_xpaths xpathsPageInstance;

	private Working_Capital_xpaths() {

	}

	public static Working_Capital_xpaths getInstance() {
		if (xpathsPageInstance == null) {
			xpathsPageInstance = new Working_Capital_xpaths();
		}
		return xpathsPageInstance;
	}
	
	
	public WebElement getcapital_cus_name() {
		return capital_cus_name;
	}

	public WebElement getcapital_cus_mobile() {
		return capital_cus_mobile;
	}

	public WebElement getcapital_cus_email() {
		return capital_cus_email;
	}

	public WebElement getcapital_pf_apply_btn() {
		return capital_pf_apply_btn;
	}

	public WebElement getcapital_otp_field() {
		return capital_otp_field;
	}

	public WebElement getcapital_otpVerifybtn() {
		return capital_otpVerifybtn;
	}

	public WebElement getcapital_loan_dob() {
		return capital_loan_dob;
	}

	public WebElement getcapital_calender_elobration() {
		return capital_calender_elobration;
	}

	public WebElement getcapital_cus_loanAmount() {
		return capital_cus_loanAmount;
	}

	public WebElement getcapital_cus_pincode2() {
		return capital_cus_pincode2;
	}

	public WebElement getcapital_pf_apply_btn1() {
		return capital_pf_apply_btn1;
	}


	@CacheLookup
	@FindBy(id="cus_name")
	private WebElement capital_cus_name;
	
	@FindBy(id="cus_mobile")
	private WebElement capital_cus_mobile;
	
	@FindBy(id="cus_email")
	private WebElement capital_cus_email;
	
	@FindBy(id="pf-apply-btn")
	private WebElement capital_pf_apply_btn;

	@FindBy(xpath="//div[@class='input_field']")
	private WebElement capital_otp_field;
	
	@FindBy(id="otpVerifybtn")
	private WebElement capital_otpVerifybtn;
	
	@FindBy(id="loan-dob")
	private WebElement capital_loan_dob;
	
	@FindBy(xpath="//*[@id=\"mat-datepicker-0\"]/mat-calendar-header/div/div/button[1]")
	private WebElement capital_calender_elobration;
	
	@FindBy(id="cus_loanAmount")
	private WebElement capital_cus_loanAmount;
	
	@FindBy(id="cus_pincode2")
	private WebElement capital_cus_pincode2;
	
	@FindBy(id="pf-apply-btn1")
	private WebElement capital_pf_apply_btn1;

}
