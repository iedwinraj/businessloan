package all_Xpaths;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class Repair_Xpaths {
	
	
	private static Repair_Xpaths xpathsPageInstance;

	private Repair_Xpaths() {

	}

	public static Repair_Xpaths getInstance() {
		if (xpathsPageInstance == null) {
			xpathsPageInstance = new Repair_Xpaths();
		}
		return xpathsPageInstance;
	}
	
	
	public WebElement getrepair_cus_name() {
		return repair_cus_name;
	}

	public WebElement getrepair_cus_mobile() {
		return repair_cus_mobile;
	}

	public WebElement getrepair_cus_email() {
		return repair_cus_email;
	}

	public WebElement getrepair_pf_apply_btn() {
		return repair_pf_apply_btn;
	}

	public WebElement getrepair_otp_field() {
		return repair_otp_field;
	}

	public WebElement getrepair_otpVerifybtn() {
		return repair_otpVerifybtn;
	}

	public WebElement getrepair_loan_dob() {
		return repair_loan_dob;
	}

	public WebElement getrepair_calender_elobration() {
		return repair_calender_elobration;
	}

	public WebElement getrepair_cus_loanAmount() {
		return repair_cus_loanAmount;
	}

	public WebElement getrepair_cus_pincode2() {
		return repair_cus_pincode2;
	}

	public WebElement getrepair_pf_apply_btn1() {
		return repair_pf_apply_btn1;
	}


	@CacheLookup
	@FindBy(id="cus_name")
	private WebElement repair_cus_name;
	
	@FindBy(id="cus_mobile")
	private WebElement repair_cus_mobile;
	
	@FindBy(id="cus_email")
	private WebElement repair_cus_email;
	
	@FindBy(id="pf-apply-btn")
	private WebElement repair_pf_apply_btn;

	@FindBy(xpath="//div[@class='input_field']")
	private WebElement repair_otp_field;
	
	@FindBy(id="otpVerifybtn")
	private WebElement repair_otpVerifybtn;
	
	@FindBy(id="loan-dob")
	private WebElement repair_loan_dob;
	
	@FindBy(xpath="//*[@id=\"mat-datepicker-0\"]/mat-calendar-header/div/div/button[1]")
	private WebElement repair_calender_elobration;
	
	@FindBy(id="cus_loanAmount")
	private WebElement repair_cus_loanAmount;
	
	@FindBy(id="cus_pincode2")
	private WebElement repair_cus_pincode2;
	
	@FindBy(id="pf-apply-btn1")
	private WebElement repair_pf_apply_btn1;

}
