package all_Xpaths;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class com_Goods_xpaths {

	private static com_Goods_xpaths xpathsPageInstance;

	private com_Goods_xpaths() {

	}

	public static com_Goods_xpaths getInstance() {
		if (xpathsPageInstance == null) {
			xpathsPageInstance = new com_Goods_xpaths();
		}
		return xpathsPageInstance;
	}
	
	
	@CacheLookup
	@FindBy(id="cus_name")
	private WebElement goods_cus_name;
	
	@FindBy(id="cus_mobile")
	private WebElement goods_cus_mobile;
	
	@FindBy(id="cus_email")
	private WebElement goods_cus_email;
	
	@FindBy(id="pf-apply-btn")
	private WebElement goods_pf_apply_btn;

	@FindBy(xpath="//div[@class='input_field']")
	private WebElement goods_otp_field;
	
	@FindBy(id="otpVerifybtn")
	private WebElement goods_otpVerifybtn;
	
	@FindBy(id="loan-dob")
	private WebElement goods_loan_dob;
	
	@FindBy(xpath="//*[@id=\"mat-datepicker-0\"]/mat-calendar-header/div/div/button[1]")
	private WebElement goods_calender_elobration;
	
	@FindBy(id="cus_loanAmount")
	private WebElement goods_cus_loanAmount;
	
	@FindBy(id="cus_pincode2")
	private WebElement goods_cus_pincode2;
	
	@FindBy(id="pf-apply-btn1")
	private WebElement goods_pf_apply_btn1;

	public WebElement getGoods_cus_name() {
		return goods_cus_name;
	}

	public WebElement getGoods_cus_mobile() {
		return goods_cus_mobile;
	}

	public WebElement getGoods_cus_email() {
		return goods_cus_email;
	}

	public WebElement getGoods_pf_apply_btn() {
		return goods_pf_apply_btn;
	}

	public WebElement getGoods_otp_field() {
		return goods_otp_field;
	}

	public WebElement getGoods_otpVerifybtn() {
		return goods_otpVerifybtn;
	}

	public WebElement getGoods_loan_dob() {
		return goods_loan_dob;
	}

	public WebElement getGoods_calender_elobration() {
		return goods_calender_elobration;
	}

	public WebElement getGoods_cus_loanAmount() {
		return goods_cus_loanAmount;
	}

	public WebElement getGoods_cus_pincode2() {
		return goods_cus_pincode2;
	}

	public WebElement getGoods_pf_apply_btn1() {
		return goods_pf_apply_btn1;
	}
	
	
	
	
}
