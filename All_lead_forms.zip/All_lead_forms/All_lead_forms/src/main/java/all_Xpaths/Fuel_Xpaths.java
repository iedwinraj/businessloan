package all_Xpaths;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class Fuel_Xpaths {


	private static Fuel_Xpaths xpathsPageInstance;

	private Fuel_Xpaths() {

	}

	public WebElement getfuel_cus_name() {
		return fuel_cus_name;
	}

	public WebElement getfuel_cus_mobile() {
		return fuel_cus_mobile;
	}

	public WebElement getfuel_cus_email() {
		return fuel_cus_email;
	}

	public WebElement getfuel_pf_apply_btn() {
		return fuel_pf_apply_btn;
	}

	public WebElement getfuel_otp_field() {
		return fuel_otp_field;
	}

	public WebElement getfuel_otpVerifybtn() {
		return fuel_otpVerifybtn;
	}

	public WebElement getfuel_loan_dob() {
		return fuel_loan_dob;
	}

	public WebElement getfuel_calender_elobration() {
		return fuel_calender_elobration;
	}

	public WebElement getfuel_cus_loanAmount() {
		return fuel_cus_loanAmount;
	}

	public WebElement getfuel_cus_pincode2() {
		return fuel_cus_pincode2;
	}

	public WebElement getfuel_pf_apply_btn1() {
		return fuel_pf_apply_btn1;
	}

	public static Fuel_Xpaths getInstance() {
		if (xpathsPageInstance == null) {
			xpathsPageInstance = new Fuel_Xpaths();
		}
		return xpathsPageInstance;
	}
	
	
	@CacheLookup
	@FindBy(id="cus_name")
	private WebElement fuel_cus_name;
	
	@FindBy(id="cus_mobile")
	private WebElement fuel_cus_mobile;
	
	@FindBy(id="cus_email")
	private WebElement fuel_cus_email;
	
	@FindBy(id="pf-apply-btn")
	private WebElement fuel_pf_apply_btn;

	@FindBy(xpath="//div[@class='input_field']")
	private WebElement fuel_otp_field;
	
	@FindBy(id="otpVerifybtn")
	private WebElement fuel_otpVerifybtn;
	
	@FindBy(id="loan-dob")
	private WebElement fuel_loan_dob;
	
	@FindBy(xpath="//*[@id=\"mat-datepicker-0\"]/mat-calendar-header/div/div/button[1]")
	private WebElement fuel_calender_elobration;
	
	@FindBy(id="cus_loanAmount")
	private WebElement fuel_cus_loanAmount;
	
	@FindBy(id="cus_pincode2")
	private WebElement fuel_cus_pincode2;
	
	@FindBy(id="pf-apply-btn1")
	private WebElement fuel_pf_apply_btn1;
	
}
