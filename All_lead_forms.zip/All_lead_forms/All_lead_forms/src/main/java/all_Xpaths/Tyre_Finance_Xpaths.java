package all_Xpaths;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class Tyre_Finance_Xpaths {
	
	private static Tyre_Finance_Xpaths xpathsPageInstance;

	private Tyre_Finance_Xpaths() {

	}

	public static Tyre_Finance_Xpaths getInstance() {
		if (xpathsPageInstance == null) {
			xpathsPageInstance = new Tyre_Finance_Xpaths();
		}
		return xpathsPageInstance;
	}
	
	
	public WebElement gettyre_cus_name() {
		return tyre_cus_name;
	}

	public WebElement gettyre_cus_mobile() {
		return tyre_cus_mobile;
	}

	public WebElement gettyre_cus_email() {
		return tyre_cus_email;
	}

	public WebElement gettyre_pf_apply_btn() {
		return tyre_pf_apply_btn;
	}

	public WebElement gettyre_otp_field() {
		return tyre_otp_field;
	}

	public WebElement gettyre_otpVerifybtn() {
		return tyre_otpVerifybtn;
	}

	public WebElement gettyre_loan_dob() {
		return tyre_loan_dob;
	}

	public WebElement gettyre_calender_elobration() {
		return tyre_calender_elobration;
	}

	public WebElement gettyre_cus_loanAmount() {
		return tyre_cus_loanAmount;
	}

	public WebElement gettyre_cus_pincode2() {
		return tyre_cus_pincode2;
	}

	public WebElement gettyre_pf_apply_btn1() {
		return tyre_pf_apply_btn1;
	}


	@CacheLookup
	@FindBy(id="cus_name")
	private WebElement tyre_cus_name;
	
	@FindBy(id="cus_mobile")
	private WebElement tyre_cus_mobile;
	
	@FindBy(id="cus_email")
	private WebElement tyre_cus_email;
	
	@FindBy(id="pf-apply-btn")
	private WebElement tyre_pf_apply_btn;

	@FindBy(xpath="//div[@class='input_field']")
	private WebElement tyre_otp_field;
	
	@FindBy(id="otpVerifybtn")
	private WebElement tyre_otpVerifybtn;
	
	@FindBy(id="loan-dob")
	private WebElement tyre_loan_dob;
	
	@FindBy(xpath="//*[@id=\"mat-datepicker-0\"]/mat-calendar-header/div/div/button[1]")
	private WebElement tyre_calender_elobration;
	
	@FindBy(id="cus_loanAmount")
	private WebElement tyre_cus_loanAmount;
	
	@FindBy(id="cus_pincode2")
	private WebElement tyre_cus_pincode2;
	
	@FindBy(id="pf-apply-btn1")
	private WebElement tyre_pf_apply_btn1;

}
