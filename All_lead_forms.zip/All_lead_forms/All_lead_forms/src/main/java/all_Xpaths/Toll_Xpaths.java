package all_Xpaths;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class Toll_Xpaths {
	
	private static Toll_Xpaths xpathsPageInstance;

	private Toll_Xpaths() {

	}

	public WebElement gettoll_cus_name() {
		return toll_cus_name;
	}

	public WebElement gettoll_cus_mobile() {
		return toll_cus_mobile;
	}

	public WebElement gettoll_cus_email() {
		return toll_cus_email;
	}

	public WebElement gettoll_pf_apply_btn() {
		return toll_pf_apply_btn;
	}

	public WebElement gettoll_otp_field() {
		return toll_otp_field;
	}

	public WebElement gettoll_otpVerifybtn() {
		return toll_otpVerifybtn;
	}

	public WebElement gettoll_loan_dob() {
		return toll_loan_dob;
	}

	public WebElement gettoll_calender_elobration() {
		return toll_calender_elobration;
	}

	public WebElement gettoll_cus_loanAmount() {
		return toll_cus_loanAmount;
	}

	public WebElement gettoll_cus_pincode2() {
		return toll_cus_pincode2;
	}

	public WebElement gettoll_pf_apply_btn1() {
		return toll_pf_apply_btn1;
	}

	public static Toll_Xpaths getInstance() {
		if (xpathsPageInstance == null) {
			xpathsPageInstance = new Toll_Xpaths();
		}
		return xpathsPageInstance;
	}
	
	
	@CacheLookup
	@FindBy(id="cus_name")
	private WebElement toll_cus_name;
	
	@FindBy(id="cus_mobile")
	private WebElement toll_cus_mobile;
	
	@FindBy(id="cus_email")
	private WebElement toll_cus_email;
	
	@FindBy(id="pf-apply-btn")
	private WebElement toll_pf_apply_btn;

	@FindBy(xpath="//div[@class='input_field']")
	private WebElement toll_otp_field;
	
	@FindBy(id="otpVerifybtn")
	private WebElement toll_otpVerifybtn;
	
	@FindBy(id="loan-dob")
	private WebElement toll_loan_dob;
	
	@FindBy(xpath="//*[@id=\"mat-datepicker-0\"]/mat-calendar-header/div/div/button[1]")
	private WebElement toll_calender_elobration;
	
	@FindBy(id="cus_loanAmount")
	private WebElement toll_cus_loanAmount;
	
	@FindBy(id="cus_pincode2")
	private WebElement toll_cus_pincode2;
	
	@FindBy(id="pf-apply-btn1")
	private WebElement toll_pf_apply_btn1;

}
