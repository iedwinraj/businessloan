package Pre_Execution;

import java.util.List;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import all_Xpaths.Toll_Xpaths;
import all_Xpaths.Website_Page;
import common_Package.BaseClass;
import excel_Package.Excel_Utils;

public class Toll_Execution extends BaseClass {

	public static void Toll_Finance_Landing_Page(String cus_name, String cus_mobile, String cus_email)
			throws Exception {

		Thread.sleep(3000);

		btnClick(Website_Page.getInstance().getToll_finance());

		Thread.sleep(3000);

		String pageUrl = getPageUrl();

		if (pageUrl.contains("https://sitsfl.stfc.in/toll-finance")) {

			System.out.println(pageUrl + "user landed the Toll-finance landing page");

		} else {

			System.out.println("user failed to land the Toll-finance  page");

		}

		sendKeys(Toll_Xpaths.getInstance().gettoll_cus_name(), cus_name);

		sendKeys(Toll_Xpaths.getInstance().gettoll_cus_mobile(), cus_mobile);

		sendKeys(Toll_Xpaths.getInstance().gettoll_cus_email(), cus_email);

		btnClick(Toll_Xpaths.getInstance().gettoll_pf_apply_btn());

	}

	public static void Otp_Pop_Up(String otp_input_field) throws Exception {
		// ------------------------For SIT-------------------------//

		/*
		 * List<WebElement> findElements =
		 * driver.findElements(By.xpath("//div[@class='input_field']")); for (int i = 0;
		 * i < findElements.size(); ++i) { WebElement checkbox =
		 * findElements.get(i).findElement(By.xpath("./input"));
		 * 
		 * sendKeys(checkbox, otp_input_field);
		 * 
		 * }
		 */

		// ========================For UAT and LIVE----------------------//

		Scanner sc = new Scanner(System.in);

		System.out.print("Enter the OTP :");

		String next = sc.next();

		Thread.sleep(5000);

		List<WebElement> findElements = driver.findElements(By.xpath("//div[@class='input_field']"));
		for (int i = 0; i < findElements.size(); ++i) {
			WebElement checkbox = findElements.get(i).findElement(By.xpath("./input"));

			sendKeys(checkbox, next);

		}

		btnClick(Toll_Xpaths.getInstance().gettoll_otpVerifybtn());
	}

	public static void DOB(String Year, String Month, String Date) throws Exception {

		try {

			Thread.sleep(3000);

			scrollDown(Toll_Xpaths.getInstance().gettoll_loan_dob());

			btnClick(Toll_Xpaths.getInstance().gettoll_loan_dob());

			btnClick(Toll_Xpaths.getInstance().gettoll_calender_elobration());

			// List<WebElement> elements =
			// driver.findElements(By.xpath("//*[@id=\"mat-datepicker-0\"]/div"));

			WebElement ul = driver.findElement(By.xpath("//*[@id=\"mat-datepicker-0\"]/div"));// xpath of ul
			Thread.sleep(3000);
			List<WebElement> allOptions = ul.findElements(By.tagName("div"));
			for (WebElement selectLi : allOptions) {

				String text = selectLi.getText();

				if (text.equals(Year)) {
					selectLi.click();
					break;
				}

			}

			List<WebElement> allOptions1 = ul.findElements(By.tagName("div"));
			for (WebElement selectLi : allOptions1) {

				if (selectLi.getText().equals(Month)) {
					selectLi.click();
					break;

				}

			}

			List<WebElement> allOptions2 = ul.findElements(By.tagName("div"));
			for (WebElement selectLi : allOptions2) {

				if (selectLi.getText().equals(Date)) {
					selectLi.click();
					break;

				}

			}

		} catch (org.openqa.selenium.StaleElementReferenceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void loan_details(String loan_Amount, String pincode, String INDEX) throws Exception {

		sendKeys(Toll_Xpaths.getInstance().gettoll_cus_loanAmount(), loan_Amount);

		sendKeys(Toll_Xpaths.getInstance().gettoll_cus_pincode2(), pincode);

		btnClick(Toll_Xpaths.getInstance().gettoll_pf_apply_btn1());

		WebElement req_submitted = Website_Page.getInstance().getReq_submitted();

		req_submitted.getText();

		if (req_submitted.getText().contains("Request Already Registered")) {

			System.out.println("Lead form succeed");

			int parseInt = Integer.parseInt(INDEX);

			Excel_Utils.writeinexcel("Lead form submitted Sucessfully", parseInt);

		} else {

			System.out.println("Lead form issue");

			int parseInt = Integer.parseInt(INDEX);

			Excel_Utils.writeinexcel("Lead form not submitted", parseInt);

		}

	}

}
