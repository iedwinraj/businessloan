package common_Package;

public class StagesConstant {

	public class Constants {
		
		public static final String BUSINESSLONA_LANDING = "Account Login";
		public static final String STAGE1_PERSONAL_DETAILS = "1";
		public static final String STAGE2_RESIDENTIAL_DETAILS = "2";
		public static final String STAGE3_BUSINESS_INFORMATIONS = "Business Information";
		
		public static final int ACCOUNTS_PAGE_SECTIONS_COUNT = 4;

	}
		

}
